import assert from 'node:assert/strict';
import {Simulation,ik,fk} from '../lib/simulation.ts';
function run(name,configure,check){const s=new Simulation();for(let i=0;i<120;i++)s.tick(1/60);configure(s);s.start();for(let i=0;i<18000&&s.running;i++)s.tick(1/60);try{check(s);console.log('PASS',name,JSON.stringify({complete:s.completed,retries:s.totalRetries,time:Math.round(s.time),error:s.error}));}catch(e){console.error('FAIL',name,s.message,JSON.stringify(s.logs));throw e;}}
for(const p of [{x:.3,y:.15,z:.8},{x:1.15,y:1.45,z:-1.05},{x:.65,y:.75,z:-.95}]){const a=ik(p);assert(a);const q=fk(a);assert(Math.hypot(p.x-q.x,p.y-q.y,p.z-q.z)<1e-6);}assert.equal(ik({x:9,y:1,z:0}),null);console.log('PASS inverse and forward kinematics');
run('sort',()=>{},s=>assert.equal(s.completed.length,3));
run('single blue',s=>{s.task='pick';s.selected=1;},s=>assert.deepEqual(s.completed,[1]));
run('stack',s=>s.task='stack',s=>assert.equal(s.completed.length,3));
run('slip recovery',s=>s.slip=true,s=>{assert.equal(s.completed.length,3);assert(s.totalRetries>=1);});
run('perception error recovery',s=>s.noise=true,s=>{assert.equal(s.completed.length,3);assert(s.totalRetries>=3);});
run('obstacle',s=>s.setObstacle(true),s=>assert.equal(s.completed.length,3));
run('random positions',s=>s.reset(true),s=>assert.equal(s.completed.length,3));
const p=new Simulation();p.start();p.paused=true;const before=p.snapshot();for(let i=0;i<60;i++)p.tick(1/60);assert.deepEqual(p.snapshot(),before);p.step();for(let i=0;i<100;i++)p.tick(1/60);assert(p.paused);assert.equal(p.phase,1);console.log('PASS pause and phase step');
const a=new Simulation();a.assembled=4;assert.equal(a.start(),false);assert(!a.running);console.log('PASS assembly interlock');
const u=new Simulation();u.blocks[0].body.position.set(8,.15,0);u.task='pick';u.start();for(let i=0;i<6000&&u.running;i++)u.tick(1/60);assert(!u.running);assert.equal(u.completed.length,0);assert.equal(u.totalRetries,4);console.log('PASS out-of-view failure cap');
const moved=new Simulation();moved.task='pick';moved.start();let shifted=false;for(let i=0;i<9000&&moved.running;i++){if(moved.phase===3&&moved.elapsed>.8&&!shifted){moved.blocks[0].body.position.x+=.35;shifted=true;}moved.tick(1/60);}assert(shifted);assert.equal(moved.completed.length,1);assert(moved.environmentReplans>=1);console.log('PASS moved target is observed and grasped again');
