"""Build the downloadable gateway from an explicit, credential-free file list."""
from pathlib import Path
from zipfile import ZipFile, ZipInfo, ZIP_DEFLATED
root = Path(__file__).resolve().parents[1]
destination = root / 'public/downloads/arm-lab-bridge.zip'
destination.parent.mkdir(parents=True, exist_ok=True)
files = ['README.md', 'server.py', 'config.example.env', 'requirements-hardware.txt', 'test_server.py', 'assembly_protocol.py', 'test_assembly.py']
with ZipFile(destination, 'w', compression=ZIP_DEFLATED) as archive:
    for filename in files:
        info = ZipInfo('arm-lab-bridge/' + filename, date_time=(2026,9,29,0,0,0))
        info.compress_type = ZIP_DEFLATED
        info.external_attr = 0o644 << 16
        archive.writestr(info, (root / 'bridge' / filename).read_bytes())
print(str(destination))
