import * as T from 'three';
import {OrbitControls} from 'three/examples/jsm/controls/OrbitControls.js';
import {RoundedBoxGeometry} from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import {SoftwareRenderer} from './software-renderer';
import type {AssemblyLab,PartId} from './assembly';
export function createAssemblyScene(host:HTMLElement,getLab:()=>AssemblyLab,onSelect:(id:PartId)=>void){
 const scene=new T.Scene();scene.background=new T.Color('#d4deea');
 let renderer:T.WebGLRenderer|SoftwareRenderer,fallback=false;
 try{renderer=new T.WebGLRenderer({antialias:true,preserveDrawingBuffer:true});}catch{renderer=new SoftwareRenderer();fallback=true;}
 renderer.setPixelRatio(Math.min(devicePixelRatio,1.6));renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.0;host.appendChild(renderer.domElement);
 const camera=new T.PerspectiveCamera(36,1,.01,10);camera.position.set(.86,.72,1.12);
 const controls=new OrbitControls(camera,renderer.domElement);controls.target.set(-.035,.115,0);controls.enableDamping=true;controls.minDistance=.65;controls.maxDistance=2.4;controls.maxPolarAngle=Math.PI*.48;
 scene.add(new T.HemisphereLight('#ffffff','#94a4b7',1.8));const light=new T.DirectionalLight('#fff',2.6);light.position.set(-.4,1.4,.6);light.castShadow=true;light.shadow.mapSize.set(1024,1024);light.shadow.camera.left=-1;light.shadow.camera.right=1;light.shadow.camera.top=1;light.shadow.camera.bottom=-1;light.shadow.camera.near=.1;light.shadow.camera.far=4;scene.add(light);
 const mat=(color:string,metalness=.12)=>new T.MeshStandardMaterial({color,metalness,roughness:.35});const white=mat('#fdfdfd'),metal=mat('#aab8c6',.7),dark=mat('#465361',.55),blue=mat('#6e94b7'),rubber=mat('#2e3642'),damaged=mat('#bf827a');
 const box=(x:number,y:number,z:number,m:T.Material,r=.004)=>{const mesh=new T.Mesh(new RoundedBoxGeometry(x,y,z,2,r),m);mesh.userData.roundedRadius=r;mesh.castShadow=true;mesh.receiveShadow=true;return mesh;};
 const cyl=(r:number,h:number,m:T.Material)=>{const mesh=new T.Mesh(new T.CylinderGeometry(r,r,h,24),m);mesh.castShadow=true;mesh.receiveShadow=true;return mesh;};
 const board=box(1.04,.025,.68,white,.014);board.position.set(0,-.018,0);scene.add(board);
 const boardEdge=box(1.045,.010,.685,mat('#8e9fb4',.35),.010);boardEdge.position.y=-.034;scene.add(boardEdge);
 const floor=box(4,.01,4,new T.MeshBasicMaterial({color:'#bdcadb'}),.001);floor.position.y=-.064;floor.userData.background=true;scene.add(floor);
 for(const x of [-.45,.45])for(const z of [-.26,.26]){const foot=cyl(.014,.023,metal);foot.position.set(x,-.048,z);scene.add(foot);}
 if(!fallback){const shadowFloor=new T.Mesh(new T.PlaneGeometry(4,4),new T.ShadowMaterial({opacity:.18}));shadowFloor.rotation.x=-Math.PI/2;shadowFloor.position.y=-.0589;shadowFloor.receiveShadow=true;scene.add(shadowFloor);}
 const base=new T.Group();base.position.set(-.035,0,-.055);scene.add(base);
 const footing=box(.25,.015,.21,metal);footing.position.y=.012;base.add(footing);
 const chassis=box(.235,.040,.195,white,.008);chassis.position.y=.037;base.add(chassis);
 const well=box(.119,.003,.10,dark,.003);well.position.y=.058;base.add(well);
 for(const x of [-.100,.100]){const boss=cyl(.010,.030,metal);boss.position.set(x,.070,0);base.add(boss);const hole=cyl(.004,.002,rubber);hole.position.set(x,.086,0);base.add(hole);}
 // Asymmetric locator rail makes orientation visible.
 const rail=box(.011,.013,.073,metal,.002);rail.position.set(-.047,.065,.004);base.add(rail);
 const tray=box(.26,.010,.48,mat('#bbc9d9'),.013);tray.position.set(.31,.002,0);scene.add(tray);
 const trays:Record<PartId,T.Vector3>={module:new T.Vector3(.30,.023,-.15),cover:new T.Vector3(.30,.018,.01),screwA:new T.Vector3(.255,.018,.145),screwB:new T.Vector3(.32,.018,.145),screwX:new T.Vector3(.385,.024,.145)};
 const nodes={} as Record<PartId,T.Group>;
 for(const id of Object.keys(trays) as PartId[]){const group=new T.Group();group.userData.part=id;nodes[id]=group;scene.add(group);group.position.copy(trays[id]);
  if(id==='module'){group.add(box(.112,.027,.089,blue,.004));const key=box(.017,.004,.020,white,.002);key.position.set(-.035,.015,.015);group.add(key);for(const x of [-.035,0,.035]){const fin=box(.008,.006,.061,metal,.001);fin.position.set(x,.018,0);group.add(fin);}}
  else if(id==='cover'){group.add(box(.242,.009,.202,white,.006));const inset=box(.073,.001,.053,metal);inset.position.y=.005;group.add(inset);for(const x of [-.1,.1]){const hole=cyl(.006,.001,rubber);hole.position.set(x,.0055,0);group.add(hole);}for(const z of [-.096,.096]){const clip=box(.045,.013,.006,white,.002);clip.position.set(0,-.006,z);group.add(clip);}}
  else {const shaft=cyl(.003,id==='screwX'?.014:.008,metal);shaft.position.y=id==='screwX'?-.010:-.007;group.add(shaft);const head=cyl(.009,.006,id==='screwX'?mat('#aa8a65',.6):metal);head.position.y=0;group.add(head);for(const angle of [0,Math.PI/2]){const slot=box(.012,.001,.002,rubber,.0004);slot.position.y=.0033;slot.rotation.y=angle;group.add(slot);}for(let i=0;i<5;i++){const thread=cyl(.0038,.0007,dark);thread.position.y=-.004-i*.0015;group.add(thread);}}
 }
 // Kinematic presentation rig; assembly validity comes from the constraint model.
 const rig=new T.Group();scene.add(rig);const root=new T.Vector3(-.37,.10,-.09);
 const foot=cyl(.070,.022,metal);foot.position.set(root.x,.009,root.z);rig.add(foot);const pedestal=cyl(.053,.077,white);pedestal.position.set(root.x,.057,root.z);rig.add(pedestal);
 const joints=[0,1,2].map((_,i)=>{const mesh=new T.Mesh(new T.SphereGeometry(i===2?.025:.039,20,14),white);rig.add(mesh);return mesh;});
 const links=[0,1].map(()=>{const mesh=box(.047,1,.052,white,.018);rig.add(mesh);return mesh;});
 const end=new T.Group();scene.add(end);const wrist=cyl(.025,.035,metal);end.add(wrist);const palm=box(.075,.022,.035,white);palm.position.y=-.02;end.add(palm);
 const fingers=[-1,1].map(sign=>{const mesh=box(.011,.043,.024,metal,.003);mesh.position.set(sign*.031,-.048,0);end.add(mesh);return mesh;});
 const driver=cyl(.011,.095,dark);driver.position.y=-.052;end.add(driver);const bit=cyl(.0028,.031,metal);bit.position.y=-.112;driver.add(bit);bit.position.y=-.061;
 const tcp=new T.Vector3(-.15,.29,.12);
 const reticle=new T.Mesh(new T.RingGeometry(.014,.016,36),new T.MeshBasicMaterial({color:'#7093b2',side:T.DoubleSide}));reticle.rotation.x=-Math.PI/2;scene.add(reticle);
 let raf=0,last=performance.now(),disposed=false;
 function location(id:PartId,lab:AssemblyLab){const p=lab.parts[id];if(p.installed||p.hole&&p.engaged){const isScrew=id.startsWith('screw');return new T.Vector3(-.035+(isScrew?(p.hole==='holeA'?-.1:.1):0),id==='module'?.065:id==='cover'?.085:.0975-p.depth/1000, -.055);}
  if(lab.held===id){const a=lab.alignment;if(a){const x=-.035+(a.target==='holeA'?-.1:a.target==='holeB'?.1:0);return new T.Vector3(x+a.dx/1000,(id==='module'?.085:id==='cover'?.093:.0975)-p.depth/1000,-.055+a.dz/1000);}return trays[id].clone().add(new T.Vector3(0,.11,0));}return trays[id].clone();}
 function animate(now:number){if(disposed)return;const dt=Math.min((now-last)/1000,.1);last=now;const lab=getLab();
  for(const id of Object.keys(nodes) as PartId[]){const node=nodes[id],p=lab.parts[id];node.position.lerp(location(id,lab),1-Math.exp(-12*dt));const angle=id.startsWith('screw')?p.turns*Math.PI*2:lab.held===id?(lab.alignment?.yaw??0)*Math.PI/180:0;node.rotation.y+=(angle-node.rotation.y)*(1-Math.exp(-10*dt));node.traverse(o=>{if(o instanceof T.Mesh){if(!o.userData.originalMaterial)o.userData.originalMaterial=o.material;o.material=p.damaged?damaged:o.userData.originalMaterial;}});}
  const goal=lab.held?nodes[lab.held].position.clone().add(new T.Vector3(0,lab.tool==='driver'?.128:.075,0)):new T.Vector3(-.20,.29,.11);tcp.lerp(goal,1-Math.exp(-12*dt));end.position.copy(tcp);fingers.forEach(f=>f.visible=lab.tool==='gripper');palm.visible=lab.tool==='gripper';driver.visible=lab.tool==='driver';end.rotation.y=lab.held?nodes[lab.held].rotation.y:0;
  const delta=tcp.clone().sub(root),rad=Math.hypot(delta.x,delta.z),dy=delta.y,L=.44,d=Math.min(.878,Math.max(.03,Math.hypot(rad,dy)));const elbow=-Math.acos(Math.max(-1,Math.min(1,(d*d-2*L*L)/(2*L*L))));const shoulder=Math.atan2(dy,rad)-Math.atan2(L*Math.sin(elbow),L+L*Math.cos(elbow));const az=Math.atan2(delta.z,delta.x);const mid=root.clone().add(new T.Vector3(Math.cos(az)*L*Math.cos(shoulder),L*Math.sin(shoulder),Math.sin(az)*L*Math.cos(shoulder)));const ps=[root,mid,tcp];ps.forEach((p,i)=>joints[i].position.copy(p));links.forEach((mesh,i)=>{const v=ps[i+1].clone().sub(ps[i]);mesh.position.copy(ps[i]).add(ps[i+1]).multiplyScalar(.5);mesh.scale.y=v.length();mesh.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),v.normalize());});
  reticle.visible=!!lab.alignment;reticle.position.set(-.035+(lab.alignment?.target==='holeA'?-.1:lab.alignment?.target==='holeB'?.1:0),.099,-.055);controls.update();renderer.render(scene,camera);raf=requestAnimationFrame(animate);
 }
 const resize=new ResizeObserver(()=>{if(!host.clientWidth||!host.clientHeight)return;camera.aspect=host.clientWidth/host.clientHeight;camera.updateProjectionMatrix();renderer.setSize(host.clientWidth,host.clientHeight);});resize.observe(host);
 const ray=new T.Raycaster();let down=[0,0];const pointerDown=(e:PointerEvent)=>{down=[e.clientX,e.clientY];};const pointerUp=(e:PointerEvent)=>{if(Math.hypot(e.clientX-down[0],e.clientY-down[1])>5)return;const r=renderer.domElement.getBoundingClientRect();ray.setFromCamera(new T.Vector2((e.clientX-r.left)/r.width*2-1,-(e.clientY-r.top)/r.height*2+1),camera);const hit=ray.intersectObjects(Object.values(nodes),true)[0];let o:T.Object3D|undefined=hit?.object;while(o&&!o.userData.part)o=o.parent??undefined;if(o)onSelect(o.userData.part);};renderer.domElement.addEventListener('pointerdown',pointerDown);renderer.domElement.addEventListener('pointerup',pointerUp);raf=requestAnimationFrame(animate);
 return {fallback,view(top:boolean){camera.position.set(...(top?[0,1.35,.001]:[.86,.72,1.12]) as [number,number,number]);controls.target.set(-.035,.115,0);controls.update();},capture(){renderer.render(scene,camera);const c=document.createElement('canvas');c.width=720;c.height=Math.round(720*renderer.domElement.height/renderer.domElement.width);c.getContext('2d')!.drawImage(renderer.domElement,0,0,c.width,c.height);return c.toDataURL('image/jpeg',.65);},dispose(){disposed=true;cancelAnimationFrame(raf);resize.disconnect();controls.dispose();renderer.domElement.removeEventListener('pointerdown',pointerDown);renderer.domElement.removeEventListener('pointerup',pointerUp);const materials=new Set<T.Material>([damaged]);scene.traverse(o=>{if(o instanceof T.Mesh){o.geometry.dispose();(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>materials.add(m));if(o.userData.originalMaterial)materials.add(o.userData.originalMaterial);}});materials.forEach(m=>m.dispose());renderer.dispose();renderer.domElement.remove();}};
}
