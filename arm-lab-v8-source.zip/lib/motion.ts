import {BASE,L1,L2,ik,fk,type V} from './kinematics.ts';
export type BoxObstacle={name:string;min:V;max:V;id?:number};
export type Capsule={name:string;a:V;b:V;r:number};
export type BodyBox={name:string;center:V;half:V};
export type CollisionHit={part:string;obstacle:string;point:V};
export type MotionContext={obstacles:BoxObstacle[];open:number;held:boolean;ignoreTarget?:number};
export const MARGIN=.018;
export const distance=(a:V,b:V)=>Math.hypot(a.x-b.x,a.y-b.y,a.z-b.z);
export const lerp=(a:V,b:V,t:number):V=>({x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t,z:a.z+(b.z-a.z)*t});
export function robotShape(angles:number[],open=1,held=false){
 const [yaw,a]=angles;const tcp=fk(angles);const elbow={x:BASE.x+L1*Math.cos(a)*Math.cos(yaw),y:BASE.y+L1*Math.sin(a),z:L1*Math.cos(a)*Math.sin(yaw)};const wrist={...tcp,y:tcp.y+.30};
 const capsules:Capsule[]=[{name:'上臂',a:BASE,b:elbow,r:.18},{name:'前臂',a:elbow,b:lerp(wrist,elbow,.10/L2),r:.15},{name:'肩关节',a:BASE,b:BASE,r:.28},{name:'肘关节',a:elbow,b:elbow,r:.24}];
 const boxes:BodyBox[]=[{name:'腕关节',center:wrist,half:{x:.22,y:.125,z:.22}},{name:'夹爪掌部',center:{...tcp,y:tcp.y+.24},half:{x:.17,y:.06,z:.12}},...[-1,1].map((sign,i)=>({name:i?'右夹指':'左夹指',center:{x:tcp.x+sign*(.17+open*.12),y:tcp.y+.08,z:tcp.z},half:{x:.04,y:.12,z:.085}}))];
 for(const sign of [-1,1]){const gap=.17+open*.12;boxes.push({name:sign<0?'左导轨':'右导轨',center:{x:tcp.x+sign*(.085+gap/2),y:tcp.y+.20,z:tcp.z},half:{x:(gap-.17+.10)/2,y:.013,z:.05}});}
 if(held)boxes.push({name:'被夹物体',center:tcp,half:{x:.16,y:.15,z:.16}});
 return {capsules,boxes,tcp,elbow,wrist};
}
// Conservative capsule test: segment against an inflated AABB. Inflation includes
// sampling clearance; corners can be rejected earlier than their exact surfaces.
export function segmentBox(a:V,b:V,box:BoxObstacle,r=0){let lo=0,hi=1;for(const axis of ['x','y','z'] as const){const d=b[axis]-a[axis],min=box.min[axis]-r,max=box.max[axis]+r;if(Math.abs(d)<1e-10){if(a[axis]<min||a[axis]>max)return false;}else{let u=(min-a[axis])/d,v=(max-a[axis])/d;if(u>v)[u,v]=[v,u];lo=Math.max(lo,u);hi=Math.min(hi,v);if(lo>hi)return false;}}return true;}
export function checkPose(angles:number[],ctx:MotionContext):CollisionHit|null{
 const shape=robotShape(angles,ctx.open,ctx.held),p=shape.tcp;
 if(!angles.every(Number.isFinite)||p.y<.12||p.x>2.7||p.x<-2.7||Math.abs(p.z)>1.95)return {part:'末端',obstacle:'工作边界',point:p};
 for(const c of shape.capsules){if(Math.min(c.a.y,c.b.y)-c.r<MARGIN)return {part:c.name,obstacle:'桌面',point:c.b};for(const ob of ctx.obstacles){if(segmentBox(c.a,c.b,ob,c.r+MARGIN))return {part:c.name,obstacle:ob.name,point:c.b};}}
 for(const b of shape.boxes){if(b.center.y-b.half.y<-.002)return {part:b.name,obstacle:'桌面',point:b.center};for(const ob of ctx.obstacles){if(ob.id!==undefined&&ob.id===ctx.ignoreTarget&&b.name.includes('夹指'))continue;const margin=b.name==='被夹物体'&&ob.id!==undefined?0:MARGIN;
  if(b.center.x+b.half.x+margin>ob.min.x&&b.center.x-b.half.x-margin<ob.max.x&&b.center.y+b.half.y+margin>ob.min.y&&b.center.y-b.half.y-margin<ob.max.y&&b.center.z+b.half.z+margin>ob.min.z&&b.center.z-b.half.z-margin<ob.max.z)return {part:b.name,obstacle:ob.name,point:b.center};}}
 return null;
}
export function checkEdge(start:V,end:V,ctx:MotionContext,stats?:{samples:number}):CollisionHit|null{
 const a=ik(start),b=ik(end);if(!a||!b)return {part:'末端',obstacle:'可达范围',point:!a?start:end};
 const angular=Math.max(...a.map((v,i)=>Math.abs(v-b[i])));const n=Math.max(1,Math.ceil(distance(start,end)/.025),Math.ceil(angular*(L1+L2)/.025));
 for(let i=0;i<=n;i++){const p=lerp(start,end,i/n),q=ik(p);if(stats)stats.samples++;if(!q)return {part:'末端',obstacle:'可达范围',point:p};const hit=checkPose(q,ctx);if(hit)return hit;}return null;
}
export type Plan={points:V[];method:string;samples:number;rejected:number;hit:CollisionHit|null};
export function planMotion(start:V,end:V,ctx:MotionContext):Plan{
 const stats={samples:0};let rejected=0,lastHit:CollisionHit|null=null;
 const valid=(a:V,b:V)=>{const hit=checkEdge(a,b,ctx,stats);if(hit){rejected++;lastHit=hit;return false;}return true;};
 const result=(points:V[],method:string):Plan=>({points,method,samples:stats.samples,rejected,hit:points.length?null:lastHit});
 const q=ik(end),qs=ik(start);if(!q||!qs){lastHit={part:'末端',obstacle:'可达范围',point:end};return result([],'无可行路径');}
 const startHit=checkPose(qs,ctx),endHit=checkPose(q,ctx);if(startHit||endHit){lastHit=startHit??endHit;return result([],'起点或终点受阻');}
 // Prefer a vertical approach/release, but every link along it must clear obstacles.
 for(const high of [Math.max(1.12,start.y,end.y),1.45,1.70,1.95]){if(high<Math.max(start.y,end.y))continue;const points=[{...start,y:high},{...end,y:high},end];let cur=start;let okay=true;for(const p of points){if(!valid(cur,p)){okay=false;break;}cur=p;}if(okay)return result(points,'全臂检查 · 抬升路径');}
 // Bounded deterministic A* on task-space nodes. Edges check the entire robot
 // configuration, not only the endpoint. No claim of complete motion planning.
 const step=.25;const xs=Array.from({length:15},(_,i)=>-1.75+i*step),ys=Array.from({length:8},(_,i)=>.20+i*step),zs=Array.from({length:13},(_,i)=>-1.5+i*step);
 const nodes:V[]=[];for(const x of xs)for(const y of ys)for(const z of zs)nodes.push({x,y,z});const nx=xs.length,ny=ys.length,nz=zs.length;
 const cache=new Map<number,boolean>();const isSafe=(i:number)=>{if(!cache.has(i)){const q=ik(nodes[i]);stats.samples++;cache.set(i,!!q&&!checkPose(q,ctx));}return cache.get(i)!;};
 const near=(p:V)=>nodes.map((n,i)=>({i,d:distance(n,p)})).filter(v=>v.d<.55).sort((a,b)=>a.d-b.d).slice(0,36).filter(v=>isSafe(v.i)&&valid(p,nodes[v.i])).slice(0,8);
 const begins=near(start),ends=new Set(near(end).map(v=>v.i));if(!begins.length||!ends.size)return result([],'无安全连接');
 const open=new Set<number>(),g=new Map<number,number>(),parent=new Map<number,number>();for(const n of begins){open.add(n.i);g.set(n.i,n.d);parent.set(n.i,-1);}let expanded=0,finish=-1;const closed=new Set<number>();
 while(open.size&&expanded<2200){let id=-1,best=Infinity;for(const n of open){const f=g.get(n)!+distance(nodes[n],end);if(f<best){best=f;id=n;}}if(ends.has(id)){finish=id;break;}open.delete(id);closed.add(id);expanded++;
  const ix=Math.floor(id/(ny*nz)),iy=Math.floor(id/nz)%ny,iz=id%nz;for(const [dx,dy,dz] of [[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]]){const x=ix+dx,y=iy+dy,z=iz+dz;if(x<0||x>=nx||y<0||y>=ny||z<0||z>=nz)continue;const next=(x*ny+y)*nz+z;if(closed.has(next)||!isSafe(next))continue;const cost=g.get(id)!+step;if(cost>=(g.get(next)??Infinity))continue;if(!valid(nodes[id],nodes[next]))continue;g.set(next,cost);parent.set(next,id);open.add(next);}}
 if(finish<0)return result([],'搜索范围内无可行路径');const chain:V[]=[end];for(let i=finish;i!==-1;i=parent.get(i)!)chain.unshift(nodes[i]);chain.unshift(start);
 // Shortcut only when the full swept robot envelope passes the same checker.
 const points:V[]=[];let at=0;while(at<chain.length-1){let next=chain.length-1;while(next>at+1&&!valid(chain[at],chain[next]))next--;points.push(chain[next]);at=next;}
 return result(points,'全臂检查 · A* 绕行');
}
