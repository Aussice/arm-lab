import * as C from 'cannon-es';
import type {Simulation} from './simulation.ts';
import {ik,type V} from './kinematics.ts';
import {checkEdge,type BoxObstacle} from './motion.ts';
export const CONTACT_TASKS=['push','press','drawer'];
export const isContactTask=(task:string)=>CONTACT_TASKS.includes(task);
export const FIXTURE={x:-.35,z:1.0};
/** Ideal one-axis guides; motion comes from physical contact or a conditional handle constraint. */
export class Manipulation {
 sim:Simulation;button:C.Body;drawer:C.Body;housing:C.Body[]=[];joint:C.PointToPointConstraint|null=null;
 pushAxis:'x'|'z'='x';pushSign=1;pushContact:V={x:0,y:.15,z:0};
 active='';origin:V|null=null;goal:V|null=null;contactFrames=0;travel=0;buttonTriggered=false;jammed=false;success=false;force=0;stepStart=0;
 constructor(sim:Simulation){this.sim=sim;
  this.button=new C.Body({mass:.12,shape:new C.Box(new C.Vec3(.25,.03,.14)),linearDamping:.8,collisionFilterGroup:32,collisionFilterMask:2});this.button.linearFactor.set(0,1,0);this.button.angularFactor.setZero();
  this.drawer=new C.Body({mass:.45,shape:new C.Box(new C.Vec3(.30,.04,.28)),linearDamping:.75,collisionFilterGroup:64,collisionFilterMask:31});this.drawer.addShape(new C.Box(new C.Vec3(.14,.055,.045)),new C.Vec3(0,.21,.33));for(const sign of [-1,1])this.drawer.addShape(new C.Box(new C.Vec3(.025,.08,.025)),new C.Vec3(sign*.10,.105,.30));this.drawer.linearFactor.set(0,0,1);this.drawer.angularFactor.setZero();
  sim.world.addBody(this.button);sim.world.addBody(this.drawer);
  const boxes=[{h:[.34,.05,.25],p:[FIXTURE.x,.05,FIXTURE.z]},{h:[.035,.13,.35],p:[FIXTURE.x-.36,.13,FIXTURE.z]},{h:[.035,.13,.35],p:[FIXTURE.x+.36,.13,FIXTURE.z]},{h:[.36,.13,.035],p:[FIXTURE.x,.13,FIXTURE.z-.33]}];
  for(const b of boxes){const body=new C.Body({mass:0,shape:new C.Box(new C.Vec3(...b.h as [number,number,number])),position:new C.Vec3(...b.p as [number,number,number])});sim.world.addBody(body);this.housing.push(body);}this.configure('none');
 }
 release(){if(this.joint)this.sim.world.removeConstraint(this.joint);this.joint=null;}
 configure(task:string){if(this.active===task)return;this.release();this.active=task;this.reset();}
 reset(){this.release();this.origin=null;this.goal=null;this.contactFrames=0;this.travel=0;this.buttonTriggered=false;this.success=false;this.force=0;
  this.button.position.set(FIXTURE.x,this.active==='press'?.22:-8,FIXTURE.z);this.drawer.position.set(FIXTURE.x,this.active==='drawer'?.17:-8,FIXTURE.z);for(const body of [this.button,this.drawer]){body.velocity.setZero();body.angularVelocity.setZero();body.quaternion.set(0,0,0,1);body.aabbNeedsUpdate=true;body.wakeUp();}
  this.housing.forEach((b,i)=>{b.position.y=(this.active==='press'?i===0:this.active==='drawer'?i>0:false)?(i===0?.05:.13):-8;b.aabbNeedsUpdate=true;});
 }
 obstacles():BoxObstacle[]{const out:BoxObstacle[]=[];const add=(name:string,center:V,half:V,id?:number)=>out.push({name,id,min:{x:center.x-half.x,y:center.y-half.y,z:center.z-half.z},max:{x:center.x+half.x,y:center.y+half.y,z:center.z+half.z}});
  for(const b of this.housing)if(b.position.y>0)add('操作台外壳',b.position,(b.shapes[0] as C.Box).halfExtents);
  if(this.active==='press')add('弹簧按钮',this.button.position,{x:.25,y:.03,z:.14},101);
  if(this.active==='drawer'){add('抽屉托盘',this.drawer.position,{x:.30,y:.04,z:.28});add('抽屉把手',this.handle(),{x:.14,y:.055,z:.045},101);for(const sign of [-1,1])add('把手支架',{x:this.drawer.position.x+sign*.10,y:this.drawer.position.y+.105,z:this.drawer.position.z+.30},{x:.025,y:.08,z:.025});}return out;
 }
 handle():V{return {x:this.drawer.position.x,y:this.drawer.position.y+.21,z:this.drawer.position.z+.33};}
 begin(){this.release();this.origin=null;this.goal=null;this.contactFrames=0;this.success=false;this.buttonTriggered=false;this.stepStart=this.sim.time;}
 beforeStep(){this.configure(isContactTask(this.sim.task)?this.sim.task:'');this.drawer.linearFactor.set(0,0,this.jammed?0:1);this.button.linearFactor.set(0,this.jammed?0:1,0);if(this.jammed){this.button.velocity.setZero();this.drawer.velocity.setZero();}
  if(this.active==='press'){const compression=Math.max(0,.22-this.button.position.y);this.button.force.y+=.12*9.81+compression*75-this.button.velocity.y*2.5;}
  if(this.active==='drawer')this.drawer.force.y+=.45*9.81;
 }
 afterStep(){const s=this.sim,body=this.active==='push'&&s.target!==null?s.blocks[s.target].body:this.active==='press'?this.button:this.drawer;
  const contacts=s.world.contacts.filter(c=>(c.bi===body&&s.robotBodies.includes(c.bj))||(c.bj===body&&s.robotBodies.includes(c.bi)));
  if(contacts.length){this.contactFrames++;this.force=Math.max(...contacts.map(c=>Math.abs(c.multiplier)));}else this.force=0;
  if(this.active==='press'){this.button.position.y=Math.max(.17,Math.min(.22,this.button.position.y));this.travel=.22-this.button.position.y;if(this.travel>.023&&contacts.length)this.buttonTriggered=true;}
  if(this.active==='drawer'){if(this.drawer.position.z<FIXTURE.z||this.drawer.position.z>FIXTURE.z+.45)this.drawer.velocity.z=0;this.drawer.position.z=Math.max(FIXTURE.z,Math.min(FIXTURE.z+.45,this.drawer.position.z));this.travel=this.drawer.position.z-FIXTURE.z;}
  if(this.active==='push'&&this.origin&&s.target!==null)this.travel=s.blocks[s.target].body.position.x-this.origin.x;
 }
 fail(reason:string){this.release();this.sim.fail(reason);}
 straight(end:V,speed:number,dt:number){const s=this.sim,d=Math.hypot(end.x-s.tcp.x,end.y-s.tcp.y,end.z-s.tcp.z),t=Math.min(1,speed*dt/Math.max(d,.0001));const next={x:s.tcp.x+(end.x-s.tcp.x)*t,y:s.tcp.y+(end.y-s.tcp.y)*t,z:s.tcp.z+(end.z-s.tcp.z)*t};const q=ik(next),hit=checkEdge(s.tcp,next,s.collisionContext());if(!q||hit){this.release();s.stopBlocked(hit,'接触操作路线受阻');return false;}s.tcp=next;s.angles=q;return d<.004;}
 preparePush(p:V){this.pushAxis=Math.abs(this.goal!.z-p.z)>.035?'z':'x';this.pushSign=this.goal![this.pushAxis]>=p[this.pushAxis]?1:-1;this.pushContact={...p,y:.15};}
 pushEnd():V{return this.pushAxis==='x'?{x:this.goal!.x-this.pushSign*.35,y:.15,z:this.pushContact.z}:{x:this.pushContact.x-.1844,y:.15,z:this.goal!.z-this.pushSign*.22};}
 approach(p:V){const s=this.sim;return s.task==='push'?(this.pushAxis==='x'?{x:p.x-this.pushSign*.43,y:.15,z:p.z}:{x:p.x-.1844,y:.15,z:p.z-this.pushSign*.29}):s.task==='press'?{x:FIXTURE.x,y:.34,z:FIXTURE.z}:{...this.handle(),y:.38};}
 tick(dt:number){const s=this.sim,task=s.task;
  if(s.phase===0&&s.elapsed>.5){const p=task==='push'?s.senseTarget():task==='press'?{...this.button.position}:this.handle();if(!p){s.stopVision('推物前未可靠识别目标');return;}s.observed={...p};if(!this.origin){this.origin={...p};this.goal=task==='push'?{x:p.x+.40,y:.15,z:p.z}:task==='press'?{x:FIXTURE.x,y:.17,z:FIXTURE.z}:{...this.handle(),z:FIXTURE.z+.73};}s.goal={...this.goal!};s.transition(1,task==='push'?'理解目标 · 沿桌面推入标记区':task==='press'?'读取按钮行程 · 目标压下至少 23 mm':'读取抽屉导轨 · 目标拉开 400 mm');}
  else if(s.phase===1&&s.elapsed>.45)s.transition(2,'规划接近姿态与接触方向');
  else if(s.phase===2&&s.elapsed>.4){const p=task==='push'?s.senseTarget():s.observed;if(!p){s.stopVision('规划前目标不可见');return;}s.observed={...p};if(task==='push')this.preparePush(p);if(s.adjustGrip(.12)&&s.planTo(this.approach(p))){s.stage='contact-approach';s.transition(3,task==='drawer'?'对准把手 · 准备夹持':'对准接触面 · 保持低速');}}
  else if(s.phase===3){if(task==='push'){const p=s.senseTarget();if(s.perception==='vision'&&!p&&s.time-s.lastVisualTime>.4){s.stopVision('推物接近途中目标不可见');return;}if(p&&s.observed&&Math.hypot(p.x-s.observed.x,p.z-s.observed.z)>.07){s.recheckEnvironment(s.target,'推物目标发生位移');return;}}if(s.move(dt)){if(task==='drawer'){const p=this.handle();if(Math.hypot(s.tcp.x-p.x,s.tcp.y-p.y,s.tcp.z-p.z)>.07){this.fail('把手已偏离夹持范围');return;}s.anchor.position.set(s.tcp.x,s.tcp.y,s.tcp.z);s.anchor.velocity.setZero();this.joint=new C.PointToPointConstraint(s.anchor,new C.Vec3(),this.drawer,new C.Vec3(0,.21,.33),70);this.joint.collideConnected=false;s.world.addConstraint(this.joint);s.log('把手夹持成立 · 沿导轨施力');}s.stage='contact-work';this.stepStart=s.time;s.setRoute([{...s.tcp},task==='push'?this.pushEnd():task==='press'?{x:FIXTURE.x,y:.205,z:FIXTURE.z}:this.goal!]);s.transition(4,task==='push'?'夹指接触推动 · 持续测量位移':task==='press'?'缓慢下压 · 等待按钮触发':'牵引把手 · 测量抽屉开度');}}
  else if(s.phase===4){if(task==='drawer'&&s.slip&&this.joint){s.slip=false;this.fail('把手夹持滑脱');return;}if(task==='push'&&s.target!==null&&Math.abs(s.blocks[s.target].body.position[this.pushAxis==='x'?'z':'x']-this.pushContact[this.pushAxis==='x'?'z':'x'])>.11){this.fail('推物侧向偏离 · 重新寻找接触面');return;}const end=task==='push'?this.pushEnd():task==='press'?{x:FIXTURE.x,y:.205,z:FIXTURE.z}:this.goal!;const done=this.straight(end,task==='press'?.065:.13,dt);if(!s.running)return;
   if(s.time-this.stepStart>14){this.fail('接触操作超时');return;}
   if(task==='drawer'&&Math.abs(this.handle().z-s.tcp.z)>.16){this.fail('抽屉阻力过大或把手夹持丢失');return;}
   if(done){this.release();s.route=[];if(s.planTo({...s.tcp,y:1.15}))s.transition(5,'脱离接触 · 检查实际结果');}}
  else if(s.phase===5){s.move(dt);if(!s.running)return;if(s.elapsed>2.2){const b=s.blocks[s.target??0].body;const good=task==='push'?this.contactFrames>0&&Math.hypot(b.position.x-this.goal!.x,b.position.z-this.goal!.z)<.10&&Math.abs(b.position.y-.15)<.06&&b.velocity.length()<.10:task==='press'?this.buttonTriggered&&this.contactFrames>0:this.travel>=.35&&Math.abs(this.drawer.velocity.z)<.06;s.error=task==='push'?Math.hypot(b.position.x-this.goal!.x,b.position.z-this.goal!.z):task==='press'?Math.max(0,.023-this.travel):Math.abs(.4-this.travel);if(good){this.success=true;s.completed=task==='push'?[s.target!]:[101];s.running=false;s.message=task==='push'?'推物完成 · 接触与落点检查通过':task==='press'?'按钮操作完成 · 检测到触发并已松开':'抽屉操作完成 · 开度与稳定性检查通过';s.log(s.message,'success');}else this.fail(task==='push'?'推物位置或稳定性未达标':task==='press'?'按钮未达到触发行程':'抽屉未达到目标开度');}}
  else if(s.phase===6&&s.elapsed>1.2)s.transition(0,'重新读取位置与接触状态 · 修正操作');
 }
 snapshot(){return {active:this.active,travel:this.travel,contactFrames:this.contactFrames,force:this.force,triggered:this.buttonTriggered,grasped:!!this.joint,jammed:this.jammed,success:this.success,goal:this.goal?{...this.goal}:null};}
}
