export type V = {x:number;y:number;z:number};
export const BASE = {x:-1.4,y:.54,z:0};
export const L1=1.55,L2=1.50;
export function ik(p:V){
 const dx=p.x-BASE.x,dz=p.z,dy=p.y+.30-BASE.y,r=Math.hypot(dx,dz),d=Math.hypot(r,dy);
 if(d>L1+L2-.015 || d<.12 || p.y<.12) return null;
 const elbow=-Math.acos(Math.max(-1,Math.min(1,(d*d-L1*L1-L2*L2)/(2*L1*L2))));
 const shoulder=Math.atan2(dy,r)-Math.atan2(L2*Math.sin(elbow),L1+L2*Math.cos(elbow));
 return [Math.atan2(dz,dx),shoulder,elbow];
}
export function fk(a:number[]):V {let r=L1*Math.cos(a[1])+L2*Math.cos(a[1]+a[2]);return {x:BASE.x+r*Math.cos(a[0]),y:BASE.y+L1*Math.sin(a[1])+L2*Math.sin(a[1]+a[2])-.3,z:r*Math.sin(a[0])};}
