export type Point={x:number;y:number};
export type ColorRegion={id:number;box:{x:number;y:number;w:number;h:number};center:Point;pixels:number;ambiguous:boolean};
export function solveCalibration(points:Point[],width:number,depth:number):number[]{
 if(points.length!==4||![width,depth].every(v=>Number.isFinite(v)&&v>=50&&v<=3000)||points.some(p=>!Number.isFinite(p.x)||!Number.isFinite(p.y)||p.x<0||p.x>1||p.y<0||p.y>1))throw new Error('请标记四个角并输入 50–3000 mm 的实际尺寸');
 const crosses=points.map((p,i)=>{const b=points[(i+1)%4],c=points[(i+2)%4];return (b.x-p.x)*(c.y-b.y)-(b.y-p.y)*(c.x-b.x);});if(!crosses.every(v=>v>.005))throw new Error('按左上、右上、右下、左下标记，四边形不能交叉或过窄');
 const targets=[{x:0,y:0},{x:width,y:0},{x:width,y:depth},{x:0,y:depth}],rows:number[][]=[];
 points.forEach((p,i)=>{const q=targets[i];rows.push([p.x,p.y,1,0,0,0,-q.x*p.x,-q.x*p.y,q.x],[0,0,0,p.x,p.y,1,-q.y*p.x,-q.y*p.y,q.y]);});
 for(let c=0;c<8;c++){let pivot=c;for(let r=c+1;r<8;r++)if(Math.abs(rows[r][c])>Math.abs(rows[pivot][c]))pivot=r;[rows[c],rows[pivot]]=[rows[pivot],rows[c]];const d=rows[c][c];if(Math.abs(d)<1e-10)throw new Error('标定点退化，请重新标记');for(let j=c;j<9;j++)rows[c][j]/=d;for(let r=0;r<8;r++){if(r===c)continue;const f=rows[r][c];for(let j=c;j<9;j++)rows[r][j]-=f*rows[c][j];}}
 return [...rows.map(r=>r[8]),1];
}
export function mapPoint(h:number[],p:Point):Point|null{const d=h[6]*p.x+h[7]*p.y+h[8];if(!Number.isFinite(d)||Math.abs(d)<1e-9)return null;const q={x:(h[0]*p.x+h[1]*p.y+h[2])/d,y:(h[3]*p.x+h[4]*p.y+h[5])/d};return Number.isFinite(q.x)&&Number.isFinite(q.y)?q:null;}
export function detectRealColors(data:Uint8ClampedArray,w:number,h:number):ColorRegion[]{
 if(data.length!==w*h*4||w<1||h<1)return [];const cls=new Int8Array(w*h).fill(-1),seen=new Uint8Array(w*h),queue=new Int32Array(w*h),out:ColorRegion[]=[];
 for(let i=0;i<w*h;i++){const r=data[i*4]/255,g=data[i*4+1]/255,b=data[i*4+2]/255,max=Math.max(r,g,b),min=Math.min(r,g,b),d=max-min;if(max<.22||d/max<.45)continue;let hue=max===r?((g-b)/d)%6:max===g?(b-r)/d+2:(r-g)/d+4;hue=(hue*60+360)%360;cls[i]=hue<28||hue>345?0:hue>190&&hue<245?1:hue>37&&hue<70?2:-1;}
 for(let i=0;i<cls.length;i++){if(cls[i]<0||seen[i])continue;let head=0,tail=1,n=0,x0=w,x1=0,y0=h,y1=0,sx=0,sy=0;queue[0]=i;seen[i]=1;while(head<tail){const j=queue[head++],x=j%w,y=Math.floor(j/w);n++;sx+=x;sy+=y;x0=Math.min(x0,x);x1=Math.max(x1,x);y0=Math.min(y0,y);y1=Math.max(y1,y);for(const k of [x?j-1:-1,x<w-1?j+1:-1,y?j-w:-1,y<h-1?j+w:-1])if(k>=0&&!seen[k]&&cls[k]===cls[i]){seen[k]=1;queue[tail++]=k;}}
 if(n>=Math.max(35,w*h*.0005))out.push({id:cls[i],box:{x:x0,y:y0,w:x1-x0+1,h:y1-y0+1},center:{x:sx/n/w,y:sy/n/h},pixels:n,ambiguous:false});}
 return [0,1,2].flatMap(id=>{const found=out.filter(v=>v.id===id).sort((a,b)=>b.pixels-a.pixels);return found.length?[{...found[0],ambiguous:found.length>1&&found[1].pixels>found[0].pixels*.25}]:[];});
}
