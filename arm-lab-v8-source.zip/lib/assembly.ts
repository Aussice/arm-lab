// Reduced-order assembly benchmark, not a contact or screw-thread FEM solver.
export const ACTIONS=['inspect','tool','pick','align','insert','turn','retract','release','verify','halt'] as const;
export const TARGETS=['assembly','gripper','driver','module','cover','screwA','screwB','screwX','socket','coverMount','holeA','holeB'] as const;
export type ActionType=typeof ACTIONS[number];
export type Target=typeof TARGETS[number];
export type PartId='module'|'cover'|'screwA'|'screwB'|'screwX';
export type AssemblyAction={type:ActionType;target:Target;dx:number;dz:number;yaw:number;amount:number;limit:number};
export type Decision={action:AssemblyAction;reason:string};
export type Scenario='standard'|'offset'|'thread'|'mixed';
export const SCENARIOS:Record<Scenario,string>={standard:'基础装配',offset:'插接错位',thread:'螺纹卡滞',mixed:'综合干扰'};
export const PART_NAMES:Record<PartId,string>={module:'定位模块',cover:'卡扣上盖',screwA:'短螺丝 A',screwB:'短螺丝 B',screwX:'长螺丝 X'};
export const RULES={moduleDepth:20,coverDepth:8,xyTolerance:.6,yawTolerance:3,screwTolerance:.35,screwYawTolerance:2,minTorque:.45,maxTorque:.70,damageTorque:.9,maxActions:80};
export const ACTION_HELP='每次只执行一个动作。tool target=gripper/driver；pick target=零件ID；align target=socket/coverMount/holeA/holeB，dx/dz/yaw是相对当前对位误差的增量(mm/度)，首次对位先移动到目标上方并读误差；insert amount=下压量mm，limit=力上限N；turn amount=有符号圈数(正拧紧/负退回)，limit=扭矩上限Nm；retract amount=退回量mm；release释放已装零件或把未装零件退回托盘；inspect读取反馈；verify做最终检查；halt停止。所有字段必须齐全，无关数值填0，无关target填assembly。仅是虚拟试件数值，不用于真实硬件。';
export function action(type:ActionType,target:Target='assembly',p:Partial<Omit<AssemblyAction,'type'|'target'>>={}):AssemblyAction{return {type,target,dx:0,dz:0,yaw:0,amount:0,limit:0,...p};}
export function validateAction(value:unknown):AssemblyAction {
 const a=value as AssemblyAction;
 if(!a||typeof a!=='object'||Array.isArray(a)||Object.keys(a).length!==7||Object.keys(a).some(k=>!['type','target','dx','dz','yaw','amount','limit'].includes(k))||!ACTIONS.includes(a.type)||!TARGETS.includes(a.target))throw new Error('装配动作字段无效');
 if(![a.dx,a.dz,a.yaw,a.amount,a.limit].every(v=>typeof v==='number'&&Number.isFinite(v))||Math.abs(a.dx)>10||Math.abs(a.dz)>10||Math.abs(a.yaw)>180||Math.abs(a.amount)>30||a.limit<0||a.limit>50)throw new Error('动作参数越界');
 if(a.type==='tool'&&!['gripper','driver'].includes(a.target)||a.type==='pick'&&!Object.hasOwn(PART_NAMES,a.target)||a.type==='align'&&!['socket','coverMount','holeA','holeB'].includes(a.target))throw new Error('动作与目标不匹配');
 if(a.type!=='align'&&(a.dx!==0||a.dz!==0||a.yaw!==0)||!['insert','turn','retract'].includes(a.type)&&(a.amount!==0||a.limit!==0)||a.type==='retract'&&a.limit!==0)throw new Error('动作包含无关参数');
 if(['inspect','insert','turn','retract','release','verify','halt'].includes(a.type)&&a.target!=='assembly')throw new Error('该动作 target 应为 assembly');
 if(['insert','retract'].includes(a.type)&&a.amount<=0||a.type==='turn'&&(a.amount===0||Math.abs(a.amount)>2||a.limit>1.2))throw new Error('深度或旋转量不合规');
 return {...a};
}
export function validateDecision(v:unknown):Decision{const d=v as Decision;if(!d||typeof d!=='object'||Object.keys(d).length!==2||Object.keys(d).some(k=>!['action','reason'].includes(k))||typeof d.reason!=='string'||!d.reason.trim()||d.reason.length>1200)throw new Error('模型必须给出单步动作和简短依据');return {action:validateAction(d.action),reason:d.reason};}
export type Part={id:PartId;installed:boolean;depth:number;turns:number;torque:number;damaged:boolean;engaged:boolean;hole:'holeA'|'holeB'|null};
export type Feedback={ok:boolean;code:string;message:string;force:number;torque:number};
export type RecordEntry={index:number;actor:string;action:AssemblyAction;reason:string;feedback:Feedback;revision:number;observation:unknown};
export class AssemblyLab {
 seed:number;scenario:Scenario;revision=0;tool:'gripper'|'driver'='gripper';held:PartId|null=null;
 alignment:{target:Target;dx:number;dz:number;yaw:number}|null=null;jam=false;force=0;verified=false;halted=false;
 parts:Record<PartId,Part>;history:RecordEntry[]=[];failures=0;recoveries=0;pendingFailure=false;interventions=0;
 last:Feedback={ok:true,code:'ready',message:'装配台就绪。先拿取定位模块。',force:0,torque:0};
 interventionLog:{revision:number;dx:number}[]=[];
 private offsetUsed=false;private threadUsed=false;
 constructor(seed=42,scenario:Scenario='standard'){
  this.seed=Math.max(1,Math.min(99999,Math.trunc(seed)||42));this.scenario=scenario;
  this.parts=Object.fromEntries(Object.keys(PART_NAMES).map(id=>[id,{id,installed:false,depth:0,turns:0,torque:0,damaged:false,engaged:false,hole:null}])) as Record<PartId,Part>;
 }
 private bias(target:Target){let n=(this.seed*1664525+TARGETS.indexOf(target)*1013904223)>>>0;const rand=()=>{n=(Math.imul(n,1664525)+1013904223)>>>0;return n/4294967296;};return {dx:Math.round((rand()-.5)*14)/10,dz:Math.round((rand()-.5)*14)/10,yaw:Math.round((rand()-.5)*12)};}
 private result(ok:boolean,code:string,message:string):Feedback{return {ok,code,message,force:this.force,torque:this.held?this.parts[this.held].torque:0};}
 execute(input:unknown,actor='manual',reason=''):Feedback {
  const a=validateAction(input);if(this.history.length>=RULES.maxActions)throw new Error('本轮达到 80 步上限，请导出记录后重置');if(this.halted)throw new Error('本轮已停止，请重置');
  const observation=this.observation();this.revision++;if(a.type!=='inspect'&&a.type!=='verify')this.force=0;if(a.type!=='inspect'&&a.type!=='verify')this.verified=false;
  const f=this.apply(a);this.last=f;
  if(!f.ok){this.failures++;this.pendingFailure=true;}else if(this.pendingFailure&&['insert','turn'].includes(a.type)){this.recoveries++;this.pendingFailure=false;}
  this.history.push({index:this.history.length+1,actor,action:a,reason:reason.slice(0,1200),feedback:{...f},revision:this.revision,observation});return f;
 }
 private apply(a:AssemblyAction):Feedback {
  const fail=(code:string,msg:string)=>this.result(false,code,msg),ok=(msg:string)=>this.result(true,'ok',msg);
  const p=this.held?this.parts[this.held]:null;
  if(a.type==='inspect')return ok('已读取当前零件、对位误差与接触反馈');
  if(a.type==='halt'){this.halted=true;return ok('控制器停止，本轮状态保留');}
  if(a.type==='verify'){const missing=this.checks().filter(c=>!c.ok);this.verified=!missing.length;return this.result(this.verified,this.verified?'complete':'incomplete',this.verified?'装配通过：插接、卡扣和两处紧固全部满足验收条件':missing.map(c=>c.label).join('；')+'尚未通过');}
  if(a.type==='tool'){if(this.held)return fail('occupied','换工具前先释放当前零件');this.tool=a.target as 'gripper'|'driver';this.alignment=null;return ok(this.tool==='gripper'?'已换平行夹爪':'已换磁性螺丝刀');}
  if(a.type==='pick'){
   if(this.held)return fail('occupied','末端已有零件，请先处理或释放');const part=this.parts[a.target as PartId];
   if(part.installed)return fail('installed','此零件已经安装');if(part.damaged)return fail('damaged','零件已损坏，本轮不可继续使用');
   if((part.id.startsWith('screw')?'driver':'gripper')!==this.tool)return fail('wrong_tool','工具不匹配：模块和上盖用夹爪，螺丝用磁性螺丝刀');
   this.held=part.id;this.alignment=null;this.jam=false;return ok('已拿取'+PART_NAMES[part.id]);
  }
  if(!p)return fail('empty','末端没有零件');
  if(p.damaged&&a.type!=='release')return fail('damaged','零件已损坏，请停止本轮并检查记录');
  if(a.type==='release'){
   if(this.jam||p.engaged&&!p.installed)return fail('engaged','先逆转退出螺纹并退回，再释放');
   const installed=p.installed;this.held=null;this.alignment=null;
   if(!installed){p.depth=0;p.turns=0;p.torque=0;p.hole=null;return ok('未安装零件已退回托盘');}return ok('已释放完成安装的零件');
  }
  if(p.installed)return fail('installed','零件已经就位，先释放末端');
  if(a.type==='retract'){
   if(p.engaged)return fail('engaged','螺纹仍啮合，先逆转退出');p.depth=Math.max(0,p.depth-a.amount);if(p.depth===0)this.jam=false;return ok('已退回 '+a.amount+' mm，可重新对位');
  }
  if(a.type==='align'){
   if(this.jam||p.depth>0)return fail('contact','先退回零件，不能在插入或卡滞时横向硬移');
   if(p.id==='module'&&a.target!=='socket'||p.id==='cover'&&a.target!=='coverMount'||p.id.startsWith('screw')&&!['holeA','holeB'].includes(a.target))return fail('wrong_target','零件与接口不匹配');
   if(p.id==='cover'&&!this.parts.module.installed)return fail('dependency','定位模块未插到底，不能安装上盖');
   if(p.id.startsWith('screw')&&!this.parts.cover.installed)return fail('dependency','上盖未扣合，不能锁螺丝');
   if(p.id.startsWith('screw')&&Object.values(this.parts).some(q=>q.id!==p.id&&q.hole===a.target&&q.installed))return fail('occupied_hole','该孔已经有一颗紧固螺丝');
   const previous=this.alignment?.target===a.target?this.alignment:this.bias(a.target);
   this.alignment={target:a.target,dx:previous.dx+a.dx,dz:previous.dz+a.dz,yaw:previous.yaw+a.yaw};
   return ok('已移动到接口上方，请读取残余对位误差');
  }
  if(!this.alignment)return fail('not_aligned','先对准接口');
  if(a.type==='insert'){
   if(this.jam)return fail('jam','当前卡滞，先退回再调整');
   if((this.scenario==='offset'||this.scenario==='mixed')&&!this.offsetUsed&&p.id==='module'){this.offsetUsed=true;this.alignment.dx+=1.2;}
   const screw=p.id.startsWith('screw'),limit=screw?8:p.id==='cover'?35:30,min=screw?2:p.id==='cover'?14:8;
   const err=Math.hypot(this.alignment.dx,this.alignment.dz),tol=screw?RULES.screwTolerance:RULES.xyTolerance;
   if(a.limit>limit){this.force=a.limit;p.damaged=true;return fail('force_damage','下压力超过试件上限，零件损坏');}
   if(err>tol||Math.abs(this.alignment.yaw)>(screw?RULES.screwYawTolerance:RULES.yawTolerance)){this.force=a.limit;this.jam=true;return fail('alignment','对位误差导致接触卡滞：退回后修正横向偏差和角度');}
   if(a.limit<min){this.force=a.limit;return fail('force_low','下压力不足，未达到所需插入深度');}
   if(screw&&p.id==='screwX')return fail('wrong_length','长螺丝会顶底，选择 8 mm 短螺丝');
   this.force=min;
   if(screw){if(a.amount>1.5)return fail('pilot_depth','螺纹初始压入不得超过 1.5 mm，后续应旋转进给');p.depth=Math.min(1,p.depth+a.amount);p.engaged=p.depth>=.8;p.hole=this.alignment.target as 'holeA'|'holeB';return ok(p.engaged?'螺纹已进入，可低扭矩旋入':'导入深度不足 0.8 mm');}
   const depth=p.id==='module'?RULES.moduleDepth:RULES.coverDepth;p.depth=Math.min(depth,p.depth+a.amount);p.installed=p.depth===depth;
   return ok(p.installed?(p.id==='module'?'定位模块已插到底':'上盖卡扣已扣合'):'插入尚未到底');
  }
  if(a.type==='turn'){
   if(!p.id.startsWith('screw')||this.tool!=='driver'||!p.engaged)return fail('not_engaged','需使用螺丝刀并先导入螺纹');
   if(a.amount<0){p.turns=Math.max(0,p.turns+a.amount);p.torque=0;this.jam=false;if(p.turns===0){p.engaged=false;p.depth=0;}return ok('已逆转退回，螺纹状态已更新');}
   if((this.scenario==='thread'||this.scenario==='mixed')&&!this.threadUsed){this.threadUsed=true;this.jam=true;p.torque=Math.min(.78,a.limit);return fail('cross_thread','旋转受阻且未产生进给：先逆转退出，再退回、对位并导入');}
   if(this.jam)return fail('cross_thread','螺纹仍卡滞，禁止继续硬拧');
   if(a.limit<.12){p.torque=a.limit;return fail('torque_low','扭矩不足以旋入，尚未产生进给');}
   const wanted=p.turns+a.amount,torque=Math.max(.12,.12+(wanted-4)*.8);
   if(torque>RULES.damageTorque&&a.limit>RULES.damageTorque){p.damaged=true;p.torque=Math.min(a.limit,torque);return fail('stripped','过拧导致滑牙，试件损坏');}
   p.turns=Math.min(wanted,4+(a.limit-.12)/.8);p.depth=1+Math.min(p.turns,4);p.torque=Math.max(.12,.12+(p.turns-4)*.8);
   p.installed=p.turns>=4&&p.torque>=RULES.minTorque-1e-9&&p.torque<=RULES.maxTorque+1e-9;
   return ok(p.installed?'螺丝就位，扭矩满足验收区间':'螺丝已旋进，尚未完成紧固');
  }
  return fail('unsupported','当前状态不能执行此动作');
 }
 checks(){return [{label:'模块插入 20 mm',ok:this.parts.module.installed&&!this.parts.module.damaged},{label:'上盖插入 8 mm 并扣合',ok:this.parts.cover.installed&&!this.parts.cover.damaged},...(['holeA','holeB'] as const).map(h=>({label:(h==='holeA'?'左':'右')+'螺丝 0.45–0.70 N·m',ok:Object.values(this.parts).some(p=>p.hole===h&&p.installed&&!p.damaged&&p.torque>=RULES.minTorque-1e-9&&p.torque<=RULES.maxTorque+1e-9)})),{label:'末端已释放',ok:this.held===null}];}
 observation(){return {version:'assembly/1',seed:this.seed,revision:this.revision,units:{position:'mm',angle:'deg',force:'N (virtual)',torque:'Nm (virtual)'},goal:'将 module 插入 socket，扣合 cover，使用两颗 8mm 短螺丝紧固 holeA/holeB，释放工具并 verify',tool:this.tool,held:this.held,alignment:this.alignment?{...this.alignment}:null,jammed:this.jam,force:this.force,parts:Object.values(this.parts).map(p=>({...p,name:PART_NAMES[p.id],length:p.id==='screwX'?14:p.id.startsWith('screw')?8:null})),rules:{...RULES,moduleForce:[8,30],coverForce:[14,35],screwPilotForce:[2,8],screwPilotDepth:[.8,1.5],screwSeatTurns:4},last:{...this.last},checks:this.checks(),verified:this.verified,halted:this.halted,steps:this.history.length,failures:this.failures,recent:this.history.slice(-5).map(h=>({action:{...h.action},feedback:{...h.feedback}}))};}
 disturb(){if(this.verified||this.halted)throw new Error('本轮已结束，请重置');if(!this.held||!this.alignment)throw new Error('先拿取零件并对位，再施加偏移');if(this.parts[this.held].installed||this.parts[this.held].engaged)throw new Error('只可扰动尚未装入的零件');this.alignment.dx+=1;this.revision++;this.interventions++;this.interventionLog.push({revision:this.revision,dx:1});this.last=this.result(false,'disturbed','人工将当前零件横向偏移 1 mm');}
 report(controller:string,modelCalls:number,latencyMs:number,inputMode:string){return {format:'arm-lab-assembly-report/1',createdAt:new Date().toISOString(),controller,inputMode,seed:this.seed,scenario:this.scenario,rules:RULES,metrics:{success:this.verified,steps:this.history.length,failedActions:this.failures,recoveries:this.recoveries,damagedParts:Object.values(this.parts).filter(p=>p.damaged).length,manualInterventions:this.interventions,modelCalls,modelLatencyMs:Math.round(latencyMs),passedChecks:this.checks().filter(c=>c.ok).length,totalChecks:5},final:this.observation(),interventions:this.interventionLog.map(i=>({...i})),history:this.history.map(h=>({...h,action:{...h.action},feedback:{...h.feedback}})),limitations:'Reduced-order state/constraint benchmark. Virtual force/torque; no threaded contact mechanics, full collision dynamics or real-hardware validation. Structured state is simulator telemetry, not image perception.'};}
}
// Deliberately labeled deterministic baseline. Never substituted for a model call.
export function baseline(lab:AssemblyLab):Decision {
 const result=(a:AssemblyAction,reason:string)=>({action:a,reason});const p=lab.held?lab.parts[lab.held]:null;
 if(lab.verified||Object.values(lab.parts).some(p=>p.damaged))return result(action('halt'),'已结束或发生不可逆损坏');
 if(p){
  if(p.installed)return result(action('release'),'零件已通过安装条件，释放工具');
  if(lab.jam){if(p.engaged)return result(action('turn','assembly',{amount:-2,limit:.3}),'螺纹卡滞，先反转退回');return result(action('retract','assembly',{amount:25}),'接触卡滞，先撤回再纠偏');}
  if(p.id==='screwX')return result(action('release'),'长度不匹配，退回长螺丝');
  const target=p.id==='module'?'socket':p.id==='cover'?'coverMount':Object.values(lab.parts).some(q=>q.hole==='holeA'&&q.installed)?'holeB':'holeA';
  if(!lab.alignment)return result(action('align',target),'移动到接口上方并读取残差');
  const e=lab.alignment,tol=p.id.startsWith('screw')?.35:.6,angle=p.id.startsWith('screw')?2:3;
  if(Math.hypot(e.dx,e.dz)>tol||Math.abs(e.yaw)>angle){if(p.depth>0)return result(action('retract','assembly',{amount:25}),'退回后才能横向校正');return result(action('align',target,{dx:-e.dx,dz:-e.dz,yaw:-e.yaw}),'按反馈误差反向修正');}
  if(p.id.startsWith('screw'))return p.engaged?result(action('turn','assembly',{amount:2,limit:.6}),'分段旋入，使用 0.6 N·m 扭矩上限'):result(action('insert','assembly',{amount:1,limit:4}),'低力导入螺纹');
  return result(action('insert','assembly',{amount:p.id==='module'?20:8,limit:p.id==='module'?12:20}),'在允许力范围内插入到目标深度');
 }
 const next=!lab.parts.module.installed?'module':!lab.parts.cover.installed?'cover':!lab.parts.screwA.installed?'screwA':!lab.parts.screwB.installed?'screwB':null;
 if(!next)return result(action('verify'),'所有零件处理完毕，执行最终验收');
 const required=next.startsWith('screw')?'driver':'gripper';if(lab.tool!==required)return result(action('tool',required),'换用该零件需要的工具');
 return result(action('pick',next),'按装配依赖选择下一零件');
}

export function applyModelDecision(lab:AssemblyLab,decision:unknown,observedRevision:number){if(lab.revision!==observedRevision)throw new Error('环境已改变，旧决策已丢弃；请重新观察');const d=validateDecision(decision);return lab.execute(d.action,'model',d.reason);}
