export const TASK_LABELS:Record<string,string>={pick:'搬运方块',sort:'三色分拣',stack:'堆叠方块',push:'推物到目标区',press:'按下按钮',drawer:'打开抽屉'};
export type TaskStep={task:string;selected:number;label:string};
export type TaskPlan={steps:TaskStep[];error:string};
const colorNames=['红色','蓝色','黄色'];
/** Deliberately bounded grammar: validate the whole request before executing anything. */
export function parseTask(text:string):TaskPlan {
 const bad=(error:string):TaskPlan=>({steps:[],error});
 if(!text.trim())return bad('输入一条任务，例如：推红色方块，然后按按钮。');
 if(text.length>240)return bad('指令过长，请使用最多 6 个简短步骤。');
 const clauses=text.trim().replace(/[。.!！]$/,'').split(/(?:，|,|；|;|\n|然后|接着|最后|再)/).map(s=>s.trim().replace(/^(?:请|先|接着|最后|再)/,'').trim()).filter(Boolean);
 if(!clauses.length||clauses.length>6)return bad('一次支持 1–6 个步骤。');
 const steps:TaskStep[]=[];
 for(const c of clauses){let task='',selected=0;
  if(/^(?:按|按下|按一下)(?:按钮|开关)$/.test(c))task='press';
  else if(/^(?:打开|拉开|开)(?:抽屉)$/.test(c))task='drawer';
  else if(/^(?:(?:把|将)?(?:所有|全部|三个|三色)?(?:方块)?(?:按颜色)?分拣(?:全部|所有)?(?:方块)?|sort(?: all)?(?: blocks)?)$/i.test(c))task='sort';
  else if(/^(?:(?:把|将)?(?:三个|所有|全部)?方块堆叠(?:起来)?|堆叠(?:三个|所有|全部)?(?:方块)?|stack(?: blocks)?)$/i.test(c))task='stack';
  else {const m=c.match(/^(?:把|将)?(?:(搬运|抓取|推|推动)(?:一下)?(红|蓝|黄|珊瑚红|湖蓝|柠檬黄)(?:色)?(?:方块|块)?|(红|蓝|黄|珊瑚红|湖蓝|柠檬黄)(?:色)?(?:方块|块)(搬运|抓取|推|推动))(?:到(?:对应)?目标区)?$/);if(m){task=/推/.test(m[1]??m[4])?'push':'pick';const color=m[2]??m[3];selected=/红/.test(color)?0:/蓝/.test(color)?1:2;}}
  if(!task)return bad('无法执行「'+c+'」。支持搬运/推指定颜色、分拣、堆叠、按按钮、打开抽屉；请去掉未支持的方向、数量或条件。');
  steps.push({task,selected,label:task==='pick'||task==='push'?TASK_LABELS[task]+' · '+colorNames[selected]:TASK_LABELS[task]});
 }
 return {steps,error:''};
}
