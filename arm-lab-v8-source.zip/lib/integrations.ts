import {validateDecision} from './assembly.ts';
import {TASK_LABELS,type TaskStep} from './task-language.ts';
export type ModelPlan={steps:TaskStep[];explanation:string;clarification:string};
export function validateModelPlan(value:unknown):ModelPlan {
 const v=value as any;if(!v||typeof v!=='object'||Object.keys(v).some(k=>!['steps','explanation','clarification'].includes(k))||!Array.isArray(v.steps)||v.steps.length>6||typeof v.explanation!=='string'||typeof v.clarification!=='string')throw new Error('模型返回格式无效');
 if(v.explanation.length>1600||v.clarification.length>600||(!v.steps.length&&!v.clarification))throw new Error('模型没有给出可执行步骤或澄清问题');
 if(v.steps.length&&v.clarification)throw new Error('模型要求澄清，暂不允许执行');
 const steps=v.steps.map((s:any)=>{if(!s||!Object.hasOwn(TASK_LABELS,s.task)||!Number.isInteger(s.selected)||s.selected<0||s.selected>2||Object.keys(s).some(k=>!['task','selected'].includes(k)))throw new Error('模型包含未支持的技能或参数');return {task:s.task,selected:s.selected,label:TASK_LABELS[s.task]+(['pick','push'].includes(s.task)?' · '+['红色','蓝色','黄色'][s.selected]:'')};});
 return {steps,explanation:v.explanation,clarification:v.clarification};
}
export type BridgeHealth={protocol:string;capabilities?:string[];model:{configured:boolean;name:string;vision:boolean};robot:{connected:boolean;driver:string;angles:number[];limits:number[][];armed:boolean;moving:boolean;fault:string;motionEnabled:boolean;result:string}};
export class BridgeClient {
 base:string;token:string;
 constructor(base:string,token:string){const u=new URL(base);if(u.username||u.password||u.search||u.hash||u.pathname!=='/')throw new Error('网关地址只能包含协议、主机和端口');if(u.protocol!=='https:'&&!(u.protocol==='http:'&&['localhost','127.0.0.1','[::1]'].includes(u.hostname)))throw new Error('远程网关必须使用 HTTPS');if(token.length<32)throw new Error('连接令牌至少 32 个字符');this.base=u.origin;this.token=token;}
 async request(path:string,body?:unknown,timeout=10000){const response=await fetch(this.base+path,{method:body===undefined?'GET':'POST',headers:{Authorization:'Bearer '+this.token,...(body===undefined?{}:{'Content-Type':'application/json'})},body:body===undefined?undefined:JSON.stringify(body),signal:AbortSignal.timeout(timeout),cache:'no-store',credentials:'omit',redirect:'error'});const data=await response.json() as Record<string,any>;if(!data||typeof data!=='object'||Array.isArray(data))throw new Error('网关响应格式无效');if(!response.ok)throw new Error(data.error||'网关请求失败');return data;}
 async health():Promise<BridgeHealth>{const v=await this.request('/health');if(v.protocol!=='arm-lab/1'||!v.robot||!v.model)throw new Error('网关协议不匹配');const r=v.robot,m=v.model;if(!Array.isArray(r.angles)||![0,6].includes(r.angles.length)||r.angles.some((a:unknown)=>typeof a!=='number'||!Number.isFinite(a))||['connected','armed','moving','motionEnabled'].some(k=>typeof r[k]!=='boolean')||typeof r.driver!=='string'||typeof r.fault!=='string'||typeof r.result!=='string'||typeof m.configured!=='boolean'||typeof m.vision!=='boolean'||typeof m.name!=='string')throw new Error('网关状态数据无效');return v as BridgeHealth;}
 async assemblyStep(instruction:string,observation:unknown,image?:string){return validateDecision(await this.request('/assembly/step',{instruction,context:{observation},...(image?{image}:{})},45000));}
 async plan(instruction:string,context:unknown,image?:string){const data=await this.request('/plan',{instruction,context,...(image?{image}:{})},45000);return validateModelPlan(data);}
}
