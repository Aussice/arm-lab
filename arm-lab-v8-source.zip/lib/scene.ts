import * as T from 'three';
import {FIXTURE} from './manipulation';
import {robotShape} from './motion';
import {SoftwareRenderer} from './software-renderer';
import {OrbitControls} from 'three/examples/jsm/controls/OrbitControls.js';
import {RoundedBoxGeometry} from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import {Simulation,BASE,L1,L2,COLORS, type EditObject, type V} from './simulation';
export function createScene(host:HTMLElement,sim:Simulation,onUpdate:()=>void){
 const scene=new T.Scene();scene.background=new T.Color('#dce3ec');scene.fog=new T.Fog('#dce3ec',13,30);
 let renderer:T.WebGLRenderer|SoftwareRenderer;let fallback=false;try{renderer=new T.WebGLRenderer({antialias:true,alpha:false});}catch{renderer=new SoftwareRenderer();fallback=true;}renderer.setPixelRatio(Math.min(window.devicePixelRatio,1.75));renderer.shadowMap.enabled=true;renderer.shadowMap.type=T.PCFSoftShadowMap;renderer.outputColorSpace=T.SRGBColorSpace;renderer.toneMapping=T.ACESFilmicToneMapping;renderer.toneMappingExposure=1.0;host.appendChild(renderer.domElement);
 const camera=new T.PerspectiveCamera(39,1,.1,60);camera.position.set(4.2,3.4,5.8);const controls=new OrbitControls(camera,renderer.domElement);controls.target.set(-.25,.8,0);controls.enableDamping=true;controls.minDistance=4.3;controls.maxDistance=14;controls.maxPolarAngle=Math.PI/2-.06;
 scene.add(new T.HemisphereLight('#ffffff','#adb9c8',1.9));const sun=new T.DirectionalLight('#fffaf4',2.6);sun.position.set(-3,8,5);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);Object.assign(sun.shadow.camera,{left:-5,right:5,top:5,bottom:-5,near:.5,far:20});sun.shadow.bias=-.0004;sun.shadow.normalBias=.015;sun.shadow.radius=5;scene.add(sun);const rim=new T.DirectionalLight('#edf3ff',1.3);rim.position.set(4,4,-5);scene.add(rim);
 const mat=(color:string,metalness=.3,roughness=.42)=>new T.MeshStandardMaterial({color,metalness,roughness});const white=mat('#fafbfc',.22,.28),black=mat('#30343a',.4,.4),metal=mat('#b7bdc5',.65,.26),accent=mat('#e4e9ef',.45,.3);
 function box(w:number,h:number,d:number,m:T.Material,rad=.03){const mesh=new T.Mesh(new RoundedBoxGeometry(w,h,d,3,rad),m);mesh.userData.roundedRadius=rad;mesh.castShadow=true;mesh.receiveShadow=true;return mesh;}
 function cyl(r:number,h:number,m:T.Material){const o=new T.Mesh(new T.CylinderGeometry(r,r,h,40),m);o.castShadow=true;o.receiveShadow=true;return o;}
 const floor=box(80,.1,80,new T.MeshBasicMaterial({color:'#c4cfdd'}));floor.userData.background=true;floor.position.y=-.91;scene.add(floor);
 if(!fallback){const shadowFloor=new T.Mesh(new T.PlaneGeometry(80,80),new T.ShadowMaterial({opacity:.16}));shadowFloor.rotation.x=-Math.PI/2;shadowFloor.position.y=-.859;shadowFloor.receiveShadow=true;scene.add(shadowFloor);}
 const table=box(6,.22,4.2,mat('#ffffff',.06,.62),.07);table.userData.background=true;table.position.y=-.115;scene.add(table);
 const edging=box(6.01,.035,4.21,mat('#8998ad',.5,.42));edging.userData.background=true;edging.position.y=-.2;scene.add(edging);
 for(const x of [-2.7,2.7])for(const z of [-1.8,1.8]){const leg=box(.12,.6,.12,metal);leg.userData.background=true;leg.position.set(x,-.55,z);scene.add(leg);}
 const gridPoints=[];for(let i=-10;i<=10;i++){const v=i*.25;if(Math.abs(v)<3){gridPoints.push(-3,.003,v*.8,3,.003,v*.8);}gridPoints.push(v,.003,-2.1,v,.003,2.1);}
 const grid=new T.LineSegments(new T.BufferGeometry().setAttribute('position',new T.Float32BufferAttribute(gridPoints,3)),new T.LineBasicMaterial({color:'#8799ae',transparent:true,opacity:.18}));scene.add(grid);
 function label(text:string,color='#cbd5d9',size=64){const c=document.createElement('canvas');c.width=512;c.height=128;const ctx=c.getContext('2d')!;ctx.fillStyle=color;ctx.font=`500 ${size}px monospace`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText(text,256,64);const texture=new T.CanvasTexture(c);const mesh=new T.Mesh(new T.PlaneGeometry(1.5,.375),new T.MeshBasicMaterial({map:texture,transparent:true,depthWrite:false}));mesh.rotation.x=-Math.PI/2;mesh.position.y=.012;return mesh;}
 const workLabel=label('ARM / 01','#89939e',48);workLabel.position.set(-1.6,.01,1.7);scene.add(workLabel);
 const targetGroup=new T.Group();scene.add(targetGroup);const pads:T.Mesh[]=[];
 for(let i=0;i<3;i++){const p=box(.43,.012,.47,new T.MeshStandardMaterial({color:COLORS[i],transparent:true,opacity:.16,roughness:.6}));p.position.set([-.10,.55,1.20][i],.008,-1.05);targetGroup.add(p);pads.push(p);const edges=new T.LineSegments(new T.EdgesGeometry(new T.BoxGeometry(.43,.018,.47)),new T.LineBasicMaterial({color:COLORS[i],transparent:true,opacity:.6}));edges.position.copy(p.position);targetGroup.add(edges);}
 const tl=label('TARGET ZONE','#929aa4',36);tl.position.set(.55,.016,-1.53);scene.add(tl);
 const obstacle=box(.36,.72,1.3,mat('#b9c2cd',.4,.45));obstacle.position.set(-.05,.36,0);scene.add(obstacle);const obstacleTop=box(.37,.045,1.31,accent,.01);obstacleTop.position.set(-.05,.742,0);scene.add(obstacleTop);
 const meshes=sim.blocks.map(b=>{const m=box(.3,.3,.3,mat(b.color,.22,.3),.014);scene.add(m);const inset=box(.13,.002,.13,mat(b.color,.5,.28),.005);inset.position.y=.151;m.add(inset);return m;});
 // Contact fixtures share their dimensions and transforms with the physics bodies.
 const fixtureGroup=new T.Group();scene.add(fixtureGroup);
 const fixtureHousing=sim.manipulation.housing.map(body=>{const h=(body.shapes[0] as any).halfExtents;const m=box(h.x*2,h.y*2,h.z*2,white,.025);fixtureGroup.add(m);return m;});
 const buttonCap=box(.50,.06,.28,metal,.025);fixtureGroup.add(buttonCap);
 const buttonFace=box(.39,.004,.19,accent,.018);buttonFace.position.y=.032;buttonCap.add(buttonFace);
 const buttonLamp=new T.Mesh(new T.SphereGeometry(.022,12,8),new T.MeshStandardMaterial({color:'#8698aa',emissive:'#000000'}));buttonLamp.position.set(.15,.037,0);buttonCap.add(buttonLamp);
 const drawerMesh=new T.Group();fixtureGroup.add(drawerMesh);
 const tray=box(.60,.08,.56,white,.02);drawerMesh.add(tray);
 const drawerHandle=box(.28,.11,.09,metal,.018);drawerHandle.position.set(0,.21,.33);drawerMesh.add(drawerHandle);
 for(const sign of [-1,1]){const bracket=box(.05,.16,.05,metal,.01);bracket.position.set(sign*.10,.105,.30);drawerMesh.add(bracket);}
 const fixtureLabel=label('CONTACT / 02','#929aa4',32);fixtureLabel.position.set(FIXTURE.x,.015,FIXTURE.z-.55);scene.add(fixtureLabel);
 const pushGoal=new T.Mesh(new T.RingGeometry(.19,.205,40),new T.MeshBasicMaterial({color:'#55728e',side:T.DoubleSide,transparent:true,opacity:.8}));pushGoal.rotation.x=-Math.PI/2;scene.add(pushGoal);
 // Modular robot, rendered from exactly the same forward kinematics as the controller.
 const modules=[new T.Group(),new T.Group(),new T.Group(),new T.Group(),new T.Group()];modules.forEach(m=>scene.add(m));
 // Cosmetic enclosures remain within the controller's conservative envelopes.
 const foot=cyl(.33,.045,black);foot.position.set(BASE.x,.028,0);modules[0].add(foot);
 const mount=cyl(.325,.065,metal);mount.position.set(BASE.x,.073,0);modules[0].add(mount);
 const pedestal=cyl(.323,.285,white);pedestal.position.set(BASE.x,.245,0);modules[0].add(pedestal);
 const ring=cyl(.325,.009,new T.MeshStandardMaterial({color:'#f7fbff',emissive:'#d3e3f5',emissiveIntensity:.3}));ring.position.set(BASE.x,.112,0);modules[0].add(ring);
 const neck=cyl(.22,.085,metal);neck.position.set(BASE.x,.407,0);modules[0].add(neck);
 function joint(r:number){const g=new T.Group();const axial=r/.23;const hub=cyl(r*.87,.27*axial,black);hub.rotation.x=Math.PI/2;g.add(hub);for(const side of [-1,1]){const bearing=cyl(r,.026,metal);bearing.rotation.x=Math.PI/2;bearing.position.z=side*.145*axial;g.add(bearing);const gasket=cyl(r*.91,.018,black);gasket.rotation.x=Math.PI/2;gasket.position.z=side*.164*axial;g.add(gasket);const cap=cyl(r*.93,.035,white);cap.rotation.x=Math.PI/2;cap.position.z=side*.184*axial;g.add(cap);const inset=cyl(r*.78,.006,white);inset.rotation.x=Math.PI/2;inset.position.z=side*.204*axial;g.add(inset);for(let i=0;i<4;i++){const screw=cyl(.009,.004,black);screw.rotation.x=Math.PI/2;screw.position.set(Math.cos(i*Math.PI/2+Math.PI/4)*r*.91,Math.sin(i*Math.PI/2+Math.PI/4)*r*.91,side*.162*axial);g.add(screw);}}return g;}
 function link(len:number,width:number){const g=new T.Group();const outer=box(width,len-.15,width*.88,white,width*.38);outer.position.y=len/2;g.add(outer);const channel=box(width*.42,len*.58,.015,black,.015);channel.position.set(0,len/2,-width*.445);g.add(channel);for(const side of [-1,1]){const seam=box(.009,len*.56,.006,metal,.003);seam.position.set(side*width*.25,len/2,-width*.45);g.add(seam);}const service=box(width*.34,.095,.012,metal,.024);service.position.set(0,len*.73,width*.443);g.add(service);return g;}
 const shoulder=joint(.23),upper=link(L1,.26),elbow=joint(.19),forearm=link(L2,.21),wrist=joint(.12);
 modules[1].add(shoulder,upper);modules[2].add(elbow,forearm);modules[3].add(wrist);
 const palm=box(.34,.12,.24,white,.045);modules[4].add(palm);const wristShaft=cyl(.075,.17,metal);modules[3].add(wristShaft);
 const guides=[box(1,.026,.10,metal,.009),box(1,.026,.10,metal,.009)];guides.forEach(g=>modules[4].add(g));
 const fingers=[new T.Group(),new T.Group()];for(let i=0;i<2;i++){const f=box(.055,.23,.16,white,.022);f.position.y=-.1;fingers[i].add(f);const pad=box(.026,.12,.12,black,.004);pad.position.set(i?-.026:.026,-.145,0);fingers[i].add(pad);modules[4].add(fingers[i]);}
 const sensor=box(.12,.055,.1,white,.014);sensor.position.set(0,.1,.1);const lens=cyl(.025,.012,new T.MeshStandardMaterial({color:'#26384b',emissive:'#375f88',emissiveIntensity:.2}));lens.rotation.x=Math.PI/2;lens.position.set(0,.1,.155);modules[4].add(sensor,lens);
 const pathMaterial=new T.LineDashedMaterial({color:'#427fa9',dashSize:.09,gapSize:.06,transparent:true,opacity:.75});let path=new T.Line(new T.BufferGeometry(),pathMaterial);scene.add(path);let prevRoute='';
 const oldPath=new T.Line(new T.BufferGeometry(),new T.LineDashedMaterial({color:'#a0aab5',dashSize:.05,gapSize:.1,transparent:true,opacity:.5}));scene.add(oldPath);let oldRouteKey='';
 const preview=new T.Mesh(new T.BoxGeometry(1,1,1),new T.MeshBasicMaterial({color:'#427fa9',wireframe:true,transparent:true,opacity:.9}));scene.add(preview);
 const reticle=new T.Mesh(new T.RingGeometry(.21,.224,48),new T.MeshBasicMaterial({color:'#427fa9',side:T.DoubleSide,transparent:true,opacity:.85}));reticle.rotation.x=-Math.PI/2;scene.add(reticle);
 const reach=new T.LineLoop(new T.BufferGeometry().setFromPoints(Array.from({length:128},(_,i)=>new T.Vector3(BASE.x+2.7*Math.cos(i/128*Math.PI*2),.009,2.7*Math.sin(i/128*Math.PI*2)))),new T.LineDashedMaterial({color:'#90a4b0',dashSize:.025,gapSize:.07,transparent:true,opacity:.18}));reach.computeLineDistances();scene.add(reach);
 const axis=new T.AxesHelper(.24);axis.position.set(-2.65,.015,1.72);scene.add(axis);
 const envGroup=new T.Group();scene.add(envGroup);const envMaterial=new T.MeshBasicMaterial({color:'#4385b5',wireframe:true,transparent:true,opacity:.23,depthWrite:false});
 const initial=robotShape(sim.angles,sim.open,true);const capMeshes=initial.capsules.map(c=>{const len=Math.hypot(c.a.x-c.b.x,c.a.y-c.b.y,c.a.z-c.b.z);const m=new T.Mesh(len>.001?new T.CapsuleGeometry(c.r,len,4,8):new T.SphereGeometry(c.r,12,8),envMaterial);envGroup.add(m);return m;});const boxMeshes=initial.boxes.map(b=>{const m=new T.Mesh(new T.BoxGeometry(b.half.x*2,b.half.y*2,b.half.z*2),envMaterial);envGroup.add(m);return m;});
 const collisionMarker=new T.Mesh(new T.SphereGeometry(.08,16,12),new T.MeshBasicMaterial({color:'#c54637'}));scene.add(collisionMarker);
 const ray=new T.Raycaster(),mouse=new T.Vector2(),plane=new T.Plane(new T.Vector3(0,1,0),0);
 let down={x:0,y:0},drag:number|null=null,offset={x:0,z:0};
 function setRay(e:PointerEvent){const r=renderer.domElement.getBoundingClientRect();mouse.set((e.clientX-r.left)/r.width*2-1,-(e.clientY-r.top)/r.height*2+1);ray.setFromCamera(mouse,camera);}
 function finishDrag(commit:boolean){if(drag===null)return;const id=drag;drag=null;if(commit)sim.endEdit();else sim.cancelEdit();controls.enabled=true;if(renderer.domElement.hasPointerCapture(id))renderer.domElement.releasePointerCapture(id);onUpdate();}
 function pointerDown(e:PointerEvent){down={x:e.clientX,y:e.clientY};if(!sim.editMode||e.button!==0||drag!==null)return;setRay(e);const hit=ray.intersectObjects(sim.obstacle?[...meshes,obstacle]:meshes,false)[0];if(!hit)return;const object:EditObject=hit.object===obstacle?'obstacle':('block'+meshes.findIndex(m=>m===hit.object)) as EditObject;e.stopImmediatePropagation();e.preventDefault();if(!sim.beginEdit(object)){onUpdate();return;}const point=ray.ray.intersectPlane(plane,new T.Vector3());if(!point){sim.cancelEdit();return;}const p=sim.editPosition(object);offset={x:p.x-point.x,z:p.z-point.z};drag=e.pointerId;controls.enabled=false;renderer.domElement.setPointerCapture(drag);onUpdate();}
 function pointerMove(e:PointerEvent){if(drag!==e.pointerId)return;e.stopImmediatePropagation();e.preventDefault();setRay(e);const point=ray.ray.intersectPlane(plane,new T.Vector3());if(point)sim.previewEdit(point.x+offset.x,point.z+offset.z);onUpdate();}
 function pointerUp(e:PointerEvent){if(drag===e.pointerId){e.stopImmediatePropagation();e.preventDefault();finishDrag(true);return;}if(sim.editMode||Math.hypot(e.clientX-down.x,e.clientY-down.y)>5)return;setRay(e);const hit=ray.intersectObjects(meshes,false)[0];if(hit&&!sim.running&&!sim.blocked){sim.selected=meshes.findIndex(m=>m===hit.object);onUpdate();}}
 function pointerCancel(e:PointerEvent){if(drag===e.pointerId)finishDrag(false);}
 function keyDown(e:KeyboardEvent){if(e.key==='Escape'&&drag!==null){e.preventDefault();finishDrag(false);}}
 renderer.domElement.addEventListener('pointerdown',pointerDown,true);renderer.domElement.addEventListener('pointermove',pointerMove,true);renderer.domElement.addEventListener('pointerup',pointerUp,true);renderer.domElement.addEventListener('pointercancel',pointerCancel,true);renderer.domElement.addEventListener('lostpointercapture',pointerCancel);window.addEventListener('keydown',keyDown);
 const resize=new ResizeObserver(()=>{camera.aspect=host.clientWidth/host.clientHeight;camera.updateProjectionMatrix();renderer.setSize(host.clientWidth,host.clientHeight);});resize.observe(host);
 let frame=0,last=performance.now(),acc=0,uiAcc=0,disposed=false;
 function render(now:number){if(disposed)return;const realDt=Math.min((now-last)/1000,.08);last=now;acc+=realDt*sim.speed;let steps=0;while(acc>=1/60&&steps<12){sim.tick(1/60);acc-=1/60;steps++;}uiAcc+=realDt;if(uiAcc>.10){onUpdate();uiAcc=0;}
  if(drag!==null&&!sim.editing)finishDrag(false);
  renderer.domElement.style.cursor=sim.editMode?(sim.editing?'grabbing':'grab'):'';
  preview.visible=!!sim.editing;if(sim.editing){const e=sim.editing,h=e.object==='obstacle'?(sim.obstacleBody.shapes[0] as any).halfExtents:{x:.15,y:.15,z:.15};preview.position.set(e.preview.x,e.preview.y,e.preview.z);preview.scale.set(h.x*2+.01,h.y*2+.01,h.z*2+.01);preview.material.color.set(e.valid?'#427fa9':'#c54637');}
  meshes.forEach((m,i)=>{const b=sim.blocks[i].body;m.position.set(b.position.x,b.position.y,b.position.z);m.quaternion.set(b.quaternion.x,b.quaternion.y,b.quaternion.z,b.quaternion.w);});
  fixtureHousing.forEach((m,i)=>{const b=sim.manipulation.housing[i];m.visible=b.position.y>0;m.position.copy(b.position as any);});
  buttonCap.visible=sim.task==='press';buttonCap.position.copy(sim.manipulation.button.position as any);buttonLamp.material.color.set(sim.manipulation.buttonTriggered?'#69a780':'#8698aa');buttonLamp.material.emissive.set(sim.manipulation.buttonTriggered?'#244432':'#000000');
  drawerMesh.visible=sim.task==='drawer';drawerMesh.position.copy(sim.manipulation.drawer.position as any);fixtureLabel.visible=sim.task==='press'||sim.task==='drawer';
  pushGoal.visible=sim.task==='push'&&!!sim.manipulation.goal;if(sim.manipulation.goal)pushGoal.position.set(sim.manipulation.goal.x,.018,sim.manipulation.goal.z);
  const [yaw,a,b]=sim.angles;const origin=new T.Vector3(BASE.x,BASE.y,0),e=new T.Vector3(BASE.x+L1*Math.cos(a)*Math.cos(yaw),BASE.y+L1*Math.sin(a),L1*Math.cos(a)*Math.sin(yaw)),w=new T.Vector3(sim.tcp.x,sim.tcp.y+.3,sim.tcp.z);
  function poseLink(o:T.Group,start:T.Vector3,end:T.Vector3){o.position.copy(start);o.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),end.clone().sub(start).normalize());}
  shoulder.position.copy(origin);shoulder.rotation.y=-yaw;poseLink(upper,origin,e);elbow.position.copy(e);elbow.rotation.y=-yaw;poseLink(forearm,e,w);wrist.position.copy(w);wrist.rotation.y=-yaw;wristShaft.position.set(w.x,w.y-.10,w.z);
  palm.position.set(sim.tcp.x,sim.tcp.y+.24,sim.tcp.z);sensor.position.set(sim.tcp.x,sim.tcp.y+.29,sim.tcp.z+.06);lens.position.set(sim.tcp.x,sim.tcp.y+.29,sim.tcp.z+.12);
  fingers.forEach((f,i)=>{const gap=.17+sim.open*.12;f.position.set(sim.tcp.x+(i?1:-1)*gap,sim.tcp.y+.18,sim.tcp.z);guides[i].scale.x=gap-.17+.10;guides[i].position.set(sim.tcp.x+(i?1:-1)*(.085+gap/2),sim.tcp.y+.20,sim.tcp.z);});
  modules.forEach((g,i)=>{g.visible=i<sim.assembled;g.position.y=sim.exploded?i*.40:0;});
  obstacle.visible=obstacleTop.visible=sim.obstacle;const obstacleHalf=(sim.obstacleBody.shapes[0] as any).halfExtents;obstacle.position.copy(sim.obstacleBody.position as any);obstacle.scale.set(1,obstacleHalf.y*2/.72,obstacleHalf.z*2/1.3);obstacleTop.position.set(sim.obstacleBody.position.x,obstacleHalf.y*2+.022,sim.obstacleBody.position.z);obstacleTop.scale.z=obstacleHalf.z*2/1.31;
  envGroup.visible=sim.showEnvelopes&&!sim.exploded&&sim.assembled===5;if(envGroup.visible){const shapes=robotShape(sim.angles,sim.open,true);shapes.capsules.forEach((c,i)=>{const m=capMeshes[i];m.position.set((c.a.x+c.b.x)/2,(c.a.y+c.b.y)/2,(c.a.z+c.b.z)/2);const dir=new T.Vector3(c.b.x-c.a.x,c.b.y-c.a.y,c.b.z-c.a.z);if(dir.length()>.001)m.quaternion.setFromUnitVectors(new T.Vector3(0,1,0),dir.normalize());});shapes.boxes.forEach((b,i)=>{boxMeshes[i].position.set(b.center.x,b.center.y,b.center.z);boxMeshes[i].visible=i<shapes.boxes.length-1||sim.held!==null;});}
  collisionMarker.visible=!!sim.collision;if(sim.collision)collisionMarker.position.set(sim.collision.point.x,sim.collision.point.y,sim.collision.point.z);
  if(sim.target!==null||!sim.running||sim.editMode){reticle.visible=!sim.exploded;const p=sim.editMode?sim.editPosition(sim.editSelection):sim.task==='press'?sim.manipulation.button.position:sim.task==='drawer'?sim.manipulation.handle():sim.blocks[sim.target??sim.selected].body.position;reticle.position.set(p.x,.015,p.z);}else reticle.visible=false;
  const route=JSON.stringify(sim.fullRoute);if(route!==prevRoute){prevRoute=route;path.geometry.dispose();path.geometry=new T.BufferGeometry().setFromPoints(sim.fullRoute.map(p=>new T.Vector3(p.x,p.y,p.z)));path.computeLineDistances();}path.visible=(sim.running||sim.blocked)&&!sim.exploded;
  const oldKey=JSON.stringify(sim.previousRoute);if(oldKey!==oldRouteKey){oldRouteKey=oldKey;oldPath.geometry.dispose();oldPath.geometry=new T.BufferGeometry().setFromPoints(sim.previousRoute.map(p=>new T.Vector3(p.x,p.y,p.z)));oldPath.computeLineDistances();}oldPath.visible=sim.previousRoute.length>0&&!sim.exploded;
  controls.update();renderer.render(scene,camera);frame=requestAnimationFrame(render);
 }
 frame=requestAnimationFrame(render);
 return {fallback,view(kind:string){if(kind==='detail'){camera.position.set(.6,2.4,3.7);controls.target.set(-.8,1.2,0);controls.update();return;}camera.position.set(...(kind==='top'?[0,8.5,.01]:kind==='front'?[.1,2.3,8]:[4.2,3.4,5.8]) as [number,number,number]);controls.target.set(-.25,.8,0);controls.update();},dispose(){disposed=true;cancelAnimationFrame(frame);resize.disconnect();controls.dispose();renderer.domElement.removeEventListener('pointerdown',pointerDown,true);renderer.domElement.removeEventListener('pointermove',pointerMove,true);renderer.domElement.removeEventListener('pointerup',pointerUp,true);renderer.domElement.removeEventListener('pointercancel',pointerCancel,true);renderer.domElement.removeEventListener('lostpointercapture',pointerCancel);window.removeEventListener('keydown',keyDown);scene.traverse(o=>{if(o instanceof T.Mesh||o instanceof T.Line){o.geometry.dispose();const ms=Array.isArray(o.material)?o.material:[o.material];ms.forEach(m=>{if('map' in m)(m.map as T.Texture)?.dispose();m.dispose();});}});renderer.dispose();renderer.domElement.remove();}};
}
