import type {V} from './kinematics.ts';
export const CAMERA={width:320,height:224,left:-3,right:3,nearZ:-2.1,farZ:2.1};
export type CameraBox={p:V;half:V;q?:{x:number;y:number;z:number;w:number};color:[number,number,number]};
export type CameraMask={x:number;z:number;partial:boolean}|null;
export type RGBFrame={width:number;height:number;data:Uint8ClampedArray};
export type Detection={id:number;p:V;confidence:number;accepted:boolean;pixels:number;box:{x:number;y:number;w:number;h:number};reason:string};
export function project(p:V){return {x:(p.x-CAMERA.left)/(CAMERA.right-CAMERA.left)*CAMERA.width,y:(p.z-CAMERA.nearZ)/(CAMERA.farZ-CAMERA.nearZ)*CAMERA.height};}
// Calibrated, orthographic RGB camera. Height is used ONLY by this rasterizer's
// z-buffer; the detector below receives RGB pixels, never geometry or IDs.
export function renderCamera(boxes:CameraBox[],exposure=1,mask:CameraMask=null):RGBFrame {
 const {width,height}=CAMERA,data=new Uint8ClampedArray(width*height*4),depth=new Float32Array(width*height).fill(-100);
 for(let i=0;i<width*height;i++){data.set([239,242,245,255],i*4);}
 const faces=[[0,1,3,2],[4,6,7,5],[0,4,5,1],[2,3,7,6],[0,2,6,4],[1,5,7,3]];
 for(const box of boxes){const {p,half:h}=box,q=box.q??{x:0,y:0,z:0,w:1};const vertices=Array.from({length:8},(_,i)=>{const x=(i&1?1:-1)*h.x,y=(i&2?1:-1)*h.y,z=(i&4?1:-1)*h.z;const tx=2*(q.y*z-q.z*y),ty=2*(q.z*x-q.x*z),tz=2*(q.x*y-q.y*x);const v={x:p.x+x+q.w*tx+q.y*tz-q.z*ty,y:p.y+y+q.w*ty+q.z*tx-q.x*tz,z:p.z+z+q.w*tz+q.x*ty-q.y*tx};return {...project(v),depth:v.y};});
  for(const f of faces)for(const tri of [[f[0],f[1],f[2]],[f[0],f[2],f[3]]]){const [a,b,c]=tri.map(i=>vertices[i]);const area=(b.y-c.y)*(a.x-c.x)+(c.x-b.x)*(a.y-c.y);if(Math.abs(area)<1e-8)continue;const x0=Math.max(0,Math.floor(Math.min(a.x,b.x,c.x))),x1=Math.min(width-1,Math.ceil(Math.max(a.x,b.x,c.x))),y0=Math.max(0,Math.floor(Math.min(a.y,b.y,c.y))),y1=Math.min(height-1,Math.ceil(Math.max(a.y,b.y,c.y)));
   for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){const u=((b.y-c.y)*(x+.5-c.x)+(c.x-b.x)*(y+.5-c.y))/area,v=((c.y-a.y)*(x+.5-c.x)+(a.x-c.x)*(y+.5-c.y))/area,w=1-u-v;if(u<0||v<0||w<0)continue;const d=u*a.depth+v*b.depth+w*c.depth,idx=y*width+x;if(d<0||d<=depth[idx])continue;depth[idx]=d;for(let k=0;k<3;k++)data[idx*4+k]=box.color[k]*exposure;}
  }
 }
 if(mask){const p=project({x:mask.x,y:0,z:mask.z});const x0=Math.floor(p.x+(mask.partial?0:-13)),x1=Math.ceil(p.x+13);for(let y=Math.max(0,Math.floor(p.y-13));y<Math.min(height,Math.ceil(p.y+13));y++)for(let x=Math.max(0,x0);x<Math.min(width,x1);x++)data.set([19,24,30,255],(y*width+x)*4);}
 return {width,height,data};
}
function colorClass(r:number,g:number,b:number){const max=Math.max(r,g,b),min=Math.min(r,g,b),d=max-min;if(max<65||d/max<.43)return -1;let hue=max===r?((g-b)/d)%6:max===g?(b-r)/d+2:(r-g)/d+4;hue=(hue*60+360)%360;if(hue>=5&&hue<30)return 0;if(hue>=195&&hue<225)return 1;if(hue>=38&&hue<65)return 2;return -1;}
// Connected components, calibrated size/shape quality and pixel-to-table mapping.
// Confidence is a heuristic quality score, not a calibrated probability.
export function detectBlocks(frame:RGBFrame):Detection[]{
 const {width:w,height:h,data}=frame,classes=new Int8Array(w*h).fill(-1),seen=new Uint8Array(w*h),queue=new Int32Array(w*h),all:Detection[]=[];
 for(let i=0;i<w*h;i++)classes[i]=colorClass(data[i*4],data[i*4+1],data[i*4+2]);
 const expectedW=.3/(CAMERA.right-CAMERA.left)*w,expectedH=.3/(CAMERA.farZ-CAMERA.nearZ)*h;
 for(let i=0;i<w*h;i++){const id=classes[i];if(id<0||seen[i])continue;let head=0,tail=1,count=0,minX=w,maxX=0,minY=h,maxY=0;queue[0]=i;seen[i]=1;
  while(head<tail){const idx=queue[head++],x=idx%w,y=Math.floor(idx/w);count++;minX=Math.min(minX,x);maxX=Math.max(maxX,x);minY=Math.min(minY,y);maxY=Math.max(maxY,y);for(const n of [x>0?idx-1:-1,x<w-1?idx+1:-1,y>0?idx-w:-1,y<h-1?idx+w:-1])if(n>=0&&!seen[n]&&classes[n]===id){seen[n]=1;queue[tail++]=n;}}
  if(count<8)continue;const bw=maxX-minX+1,bh=maxY-minY+1,areaRatio=count/(expectedW*expectedH),sizeScore=Math.min(1,bw/expectedW,bh/expectedH),confidence=Math.max(0,Math.min(1,areaRatio)*sizeScore*Math.min(1,2/Math.max(bw/bh,bh/bw)));const clipped=minX===0||minY===0||maxX===w-1||maxY===h-1;const accepted=confidence>=.68&&areaRatio<1.8&&!clipped;
  all.push({id,p:{x:CAMERA.left+(minX+maxX+1)/2/w*(CAMERA.right-CAMERA.left),y:.15,z:CAMERA.nearZ+(minY+maxY+1)/2/h*(CAMERA.farZ-CAMERA.nearZ)},confidence,accepted,pixels:count,box:{x:minX,y:minY,w:bw,h:bh},reason:clipped?'触及画面边缘':areaRatio>=1.8?'尺寸异常':accepted?'可用于定位':'轮廓不完整 / 质量不足'});
 }
 return [0,1,2].flatMap(id=>{const candidates=all.filter(d=>d.id===id).sort((a,b)=>b.pixels-a.pixels);if(!candidates.length)return [];const d=candidates[0];if(candidates.length>1&&candidates[1].pixels>d.pixels*.35)return [{...d,accepted:false,reason:'同色目标存在歧义'}];return [d];});
}
