"""Local protocol tests. No real model service or hardware is exercised."""
import copy, json, os, tempfile, threading, unittest
from unittest.mock import patch
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from server import Gateway, ModelClient, MockRobot, RobotController, validate_plan, load_env_file
PLAN={'steps':[{'task':'pick','selected':1}], 'explanation':'搬运蓝色方块', 'clarification':''}
LIMITS=[[-90,90] for _ in range(6)]

class ConfigTests(unittest.TestCase):
    def test_literal_config_no_execution_and_environment_precedence(self):
        with tempfile.TemporaryDirectory() as directory, patch.dict(os.environ,{'MODEL_NAME':'existing'},clear=True):
            path=os.path.join(directory,'config.env')
            with open(path,'w',encoding='utf-8') as f:f.write('MODEL_NAME=ignored\nMODEL_API_KEY="$(never-execute)"\n')
            load_env_file(path)
            self.assertEqual(os.environ['MODEL_NAME'],'existing');self.assertEqual(os.environ['MODEL_API_KEY'],'$(never-execute)')
            with open(path,'w',encoding='utf-8') as f:f.write('PATH=bad')
            with self.assertRaises(ValueError):load_env_file(path)

class RobotTests(unittest.TestCase):
    def setUp(self):
        self.now=10.;self.driver=MockRobot();self.robot=RobotController(self.driver,LIMITS,True,lambda:self.now)
        self.lease=self.robot.arm()['lease']
    def command(self,**changes):
        value={'id':'command-0001','lease':self.lease,'angles':[1.,0,0,0,0,0],'speed':5};value.update(changes);return value
    def test_readonly_and_no_driver(self):
        for r in [RobotController(),RobotController(self.driver,LIMITS)]:
            with self.assertRaises(ValueError):r.arm()
        self.assertFalse(RobotController().status()['connected'])
    def test_reject_unknown_limits(self):
        for limits in [[],[[0,1]],[[1,0]]*6,[[0,float('nan')]]*6]:
            with self.assertRaises(ValueError):RobotController(self.driver,limits,True)
    def test_command_feedback_and_duplicate(self):
        self.assertTrue(self.robot.move(self.command())['accepted']);self.robot.watch()
        self.assertIsNone(self.robot.target);self.assertIn('确认到位',self.robot.status()['result'])
        with self.assertRaises(ValueError):self.robot.move(self.command())
    def test_bad_commands_never_move(self):
        for changes in [{'lease':'bad'},{'angles':[float('nan')]*6},{'angles':[True]*6},{'angles':[91]*6},{'angles':[6]*6},{'speed':11},{'speed':True},{'id':'short'}]:
            with self.assertRaises(ValueError):self.robot.move(self.command(**changes))
        self.assertEqual(self.driver.angles,[0]*6)
    def test_busy_and_overlapping_lease(self):
        with self.assertRaises(ValueError):self.robot.arm()
        self.robot.move(self.command())
        with self.assertRaises(ValueError):self.robot.move(self.command(id='command-0002'))
    def test_heartbeat_renewal_and_expiry_stops(self):
        self.now+=2;self.robot.beat(self.lease);self.now+=2;self.robot.watch();self.assertTrue(self.robot.lease)
        self.now+=1;self.robot.watch();self.assertFalse(self.robot.lease);self.assertEqual(self.driver.stops,1)
        with self.assertRaises(ValueError):self.robot.move(self.command())
    def test_feedback_loss_stops_and_revokes(self):
        self.driver.read=lambda:([float('nan')]*6,False);self.robot.watch()
        self.assertFalse(self.robot.lease);self.assertIn('反馈丢失',self.robot.fault);self.assertEqual(self.driver.stops,1)
    def test_feedback_deadline_no_automatic_retry(self):
        self.driver.move=lambda angles,speed:None;self.robot.move(self.command(angles=[3,0,0,0,0,0]));self.now+=13;self.robot.heartbeat=self.now;self.robot.watch()
        self.assertFalse(self.robot.lease);self.assertIn('未通过',self.robot.fault);self.assertEqual(self.driver.stops,1)
    def test_unconfirmed_stop_reports_fault(self):
        def fail():raise OSError('serial failure')
        self.driver.stop=fail
        with self.assertRaises(ValueError):self.robot.stop()
        self.assertFalse(self.robot.lease);self.assertIn('未获设备确认',self.robot.fault)

class Provider(BaseHTTPRequestHandler):
    answer=PLAN;seen={};mode='ok'
    def log_message(self,*args):pass
    def do_POST(self):
        Provider.seen={'path':self.path,'body':json.loads(self.rfile.read(int(self.headers['Content-Length']))),'auth':self.headers.get('Authorization')}
        if self.mode=='error':
            self.send_response(401);self.end_headers();self.wfile.write(b'super-secret-provider-detail');return
        response={'choices':[{'finish_reason':'length' if self.mode=='truncated' else 'stop','message':{'content':json.dumps(self.answer),'refusal':'blocked' if self.mode=='refusal' else None}}]}
        self.send_response(200);self.end_headers();self.wfile.write(json.dumps(response).encode())

class ModelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.http=ThreadingHTTPServer(('127.0.0.1',0),Provider);cls.thread=threading.Thread(target=cls.http.serve_forever,daemon=True);cls.thread.start()
    @classmethod
    def tearDownClass(cls):cls.http.shutdown();cls.http.server_close();cls.thread.join()
    def setUp(self):
        Provider.answer=copy.deepcopy(PLAN);Provider.mode='ok'
        with patch.dict(os.environ,{'MODEL_BASE_URL':f'http://127.0.0.1:{self.http.server_port}/v1','MODEL_NAME':'protocol-test','MODEL_API_KEY':'test-key','MODEL_VISION':'1'},clear=True):self.model=ModelClient()
    def test_real_http_provider_payload_and_plan(self):
        self.assertEqual(self.model.plan({'instruction':'请移动蓝色方块','context':{}}),PLAN)
        self.assertEqual(Provider.seen['path'],'/v1/chat/completions');self.assertEqual(Provider.seen['auth'],'Bearer test-key')
        self.assertEqual(Provider.seen['body']['response_format']['type'],'json_schema')
    def test_invalid_output_rejected(self):
        Provider.answer={'steps':[{'task':'move_joints','selected':0}],'explanation':'','clarification':''}
        with self.assertRaises(ValueError):self.model.plan({'instruction':'x'})
    def test_refusal_and_truncation_rejected(self):
        for mode in ['refusal','truncated']:
            Provider.mode=mode
            with self.assertRaises(ValueError):self.model.plan({'instruction':'x'})
    def test_upstream_details_redacted(self):
        Provider.mode='error'
        with self.assertRaises(ValueError) as cm:self.model.plan({'instruction':'x'})
        self.assertNotIn('super-secret',str(cm.exception));self.assertIn('HTTP 401',str(cm.exception))
    def test_image_sent_only_when_explicit(self):
        self.model.plan({'instruction':'x'});self.assertEqual(len(Provider.seen['body']['messages'][1]['content']),1)
        image='data:image/png;base64,iVBORw0KGgo='
        self.model.plan({'instruction':'x','image':image});self.assertEqual(Provider.seen['body']['messages'][1]['content'][1]['image_url']['url'],image)
        self.model.vision=False
        with self.assertRaises(ValueError):self.model.plan({'instruction':'x','image':image})
    def test_input_and_image_validation(self):
        for body in [{'instruction':''},{'instruction':'x'*2001},{'instruction':'x','context':[]},{'instruction':'x','image':'https://example.org/image'},{'instruction':'x','image':'data:image/png;base64,ZmFrZQ=='}]:
            with self.assertRaises(ValueError):self.model.plan(body)
    def test_plan_schema_enforcement(self):
        for value in [{**PLAN,'extra':1},{**PLAN,'clarification':'question'},{**PLAN,'steps':[]},{**PLAN,'steps':[{'task':'pick','selected':True}]},{**PLAN,'steps':PLAN['steps']*7}]:
            with self.assertRaises(ValueError):validate_plan(value)
        self.assertEqual(validate_plan({**PLAN,'steps':[],'clarification':'Which?'})['steps'],[])

class GatewayTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with patch.dict(os.environ,{},clear=True):model=ModelClient()
        cls.robot=RobotController();cls.http=Gateway(('127.0.0.1',0),'t'*32,'https://allowed.example',cls.robot,model)
        cls.thread=threading.Thread(target=cls.http.serve_forever,daemon=True);cls.thread.start()
    @classmethod
    def tearDownClass(cls):cls.http.shutdown();cls.http.server_close();cls.thread.join()
    def request(self,path='/health',token='t'*32,origin='https://allowed.example',body=None,method=None):
        headers={'Authorization':'Bearer '+token,'Origin':origin,'Content-Type':'application/json'}
        req=Request(f'http://127.0.0.1:{self.http.server_port}'+path,body,headers,method=method)
        try:
            with urlopen(req,timeout=2) as r:return r.status,r.read(),r.headers
        except HTTPError as e:return e.code,e.read(),e.headers
    def test_auth_and_exact_origin(self):
        self.assertEqual(self.request(token='bad')[0],401)
        self.assertEqual(self.request(origin='https://evil.example')[0],403)
        code,data,headers=self.request();self.assertEqual(code,200);self.assertEqual(headers['Access-Control-Allow-Origin'],'https://allowed.example')
        self.assertFalse(json.loads(data)['robot']['connected']);self.assertNotIn(b't'*32,data)
    def test_preflight_and_unknown_path(self):
        self.assertEqual(self.request(method='OPTIONS')[0],204);self.assertEqual(self.request(method='OPTIONS',origin='null')[0],403);self.assertEqual(self.request('/missing')[0],404)
    def test_no_unauthorized_motion_and_no_nan(self):
        self.assertEqual(self.request('/robot/stop',token='bad',body=b'{}')[0],401)
        self.assertEqual(self.request('/robot/arm',body=b'{}')[0],400)
        self.assertEqual(self.request('/robot/move',body=b'{"angles":[NaN]}')[0],400)
        self.assertEqual(self.request('/plan',body=b'[]')[0],400)
        self.assertEqual(self.request('/plan',body=b'{"instruction":"x"}')[0],400)

if __name__=='__main__':unittest.main()
