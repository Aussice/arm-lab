"""Assembly protocol tests use an HTTP fake model, never a paid model or hardware."""
import copy, json, os, threading, unittest
from http.server import ThreadingHTTPServer
from unittest.mock import patch
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from assembly_protocol import validate_decision
from server import ModelClient, Gateway, RobotController
from test_server import Provider
DECISION={'action':{'type':'inspect','target':'assembly','dx':0,'dz':0,'yaw':0,'amount':0,'limit':0},'reason':'先观察装配状态'}
class AssemblyProtocolTests(unittest.TestCase):
    def test_strict_action_validation(self):
        self.assertEqual(validate_decision(DECISION),DECISION)
        for updates in [{'type':'send_angles'},{'target':'robot'},{'dx':float('inf')},{'amount':True},{'limit':1}]:
            value=copy.deepcopy(DECISION);value['action'].update(updates)
            with self.assertRaises(ValueError):validate_decision(value)
        for value in [{**DECISION,'success':True},{'action':DECISION['action'],'reason':''},{'action':None,'reason':'x'}]:
            with self.assertRaises(ValueError):validate_decision(value)
    def test_valid_increment_and_signed_rotation(self):
        for a in [{'type':'align','target':'socket','dx':-.6,'dz':.2,'yaw':-2,'amount':0,'limit':0},{'type':'turn','target':'assembly','dx':0,'dz':0,'yaw':0,'amount':-2,'limit':.3}]:
            self.assertEqual(validate_decision({'action':a,'reason':'根据反馈修正'})['action'],a)
    def test_no_extraneous_action_parameters(self):
        for updates in [{'type':'tool','target':'socket'},{'type':'pick','target':'holeA'},{'type':'retract','amount':2,'limit':3},{'type':'insert','amount':-1,'limit':4},{'type':'turn','amount':3,'limit':.6},{'type':'turn','amount':1,'limit':2},{'type':'insert','target':'socket','amount':1,'limit':4}]:
            value=copy.deepcopy(DECISION);value['action'].update(updates)
            with self.assertRaises(ValueError):validate_decision(value)

class AssemblyHTTPTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.provider=ThreadingHTTPServer(('127.0.0.1',0),Provider);cls.pt=threading.Thread(target=cls.provider.serve_forever,daemon=True);cls.pt.start()
        with patch.dict(os.environ,{'MODEL_BASE_URL':f'http://127.0.0.1:{cls.provider.server_port}/v1','MODEL_NAME':'assembly-protocol-test','MODEL_VISION':'1'},clear=True):cls.model=ModelClient()
        cls.robot=RobotController();cls.gateway=Gateway(('127.0.0.1',0),'t'*32,'https://example.org',cls.robot,cls.model);cls.gt=threading.Thread(target=cls.gateway.serve_forever,daemon=True);cls.gt.start()
    @classmethod
    def tearDownClass(cls):
        for s,t in [(cls.gateway,cls.gt),(cls.provider,cls.pt)]:s.shutdown();s.server_close();t.join()
    def setUp(self):Provider.answer=copy.deepcopy(DECISION);Provider.mode='ok'
    def post(self,token='t'*32):
        req=Request(f'http://127.0.0.1:{self.gateway.server_port}/assembly/step',json.dumps({'instruction':'组装模块','context':{'observation':{'revision':7,'held':'module','last':{'code':'alignment'}}}}).encode(),{'Content-Type':'application/json','Authorization':'Bearer '+token,'Origin':'https://example.org'})
        try:
            with urlopen(req,timeout=3) as r:return r.status,json.load(r)
        except HTTPError as e:return e.code,json.load(e)
    def test_end_to_end_step_uses_assembly_schema_and_fresh_feedback(self):
        code,data=self.post();self.assertEqual(code,200);self.assertEqual(data,DECISION)
        payload=Provider.seen['body'];self.assertEqual(payload['response_format']['json_schema']['name'],'assembly_step')
        self.assertIn('VIRTUAL assembly',payload['messages'][0]['content'])
        observation=json.loads(payload['messages'][1]['content'][0]['text'])['observations']['observation'];self.assertEqual(observation['revision'],7);self.assertEqual(observation['last']['code'],'alignment')
        self.assertFalse(self.robot.status()['connected']);self.assertFalse(self.robot.motion)
    def test_unauthorized_step_does_not_call_provider(self):
        Provider.seen={};code,_=self.post('bad');self.assertEqual(code,401);self.assertEqual(Provider.seen,{})
    def test_invalid_model_claim_never_returned_as_valid_action(self):
        Provider.answer={**DECISION,'completed':True};code,data=self.post();self.assertEqual(code,400);self.assertIn('error',data)
    def test_assembly_route_is_discoverable(self):
        req=Request(f'http://127.0.0.1:{self.gateway.server_port}/health',headers={'Authorization':'Bearer '+'t'*32})
        with urlopen(req,timeout=3) as r:self.assertIn('assembly/1',json.load(r)['capabilities'])
if __name__=='__main__':unittest.main()
