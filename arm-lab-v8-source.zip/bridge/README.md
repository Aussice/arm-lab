# ARM LAB 本地接入包 · v8

把模型服务、当前电脑摄像头和机械臂控制器连接到 ARM LAB。网页继续采用白色工作台设计。

## 接入状态与边界

| 路径 | 本版本实现 | 激活依赖 |
| --- | --- | --- |
| 通用语言/视觉模型 | OpenAI-compatible Chat Completions；结构化计划、双端校验、澄清、仿真结果检查 | 服务地址、模型名、自己的 API Key；需服务支持 JSON 输出，发图还需支持图像输入 |
| 真实摄像头 | 浏览器实时采集、摄像头选择、RGB 三色区域检测、四点平面标定 | 当前浏览器的摄像头权限及实际相机 |
| 实体机械臂 | myCobot 280 串口适配、六关节读数、只读模式、微动、到位检查、停止和心跳看门狗 | 对应设备、端口、波特率、经核对的关节限位、可用的实体停止设施 |

本包已做软件与协议测试；尚未在你的模型账户、摄像头和实体机械臂上联调。模型的六种技能计划只能在仿真中执行。真实硬件当前为**状态读取和关节微动联调**，没有实现图像到实体自主抓取。平面二维坐标不是机器人基座坐标；后续需要设备几何、工具参数、手眼/基座标定、碰撞模型和实机任务验收。软件看门狗不是实时安全控制器，进程崩溃或串口驱动阻塞时不能保证停机。

## 1. 准备本地网关

在与机械臂连接的电脑安装 Python 3.10+。先解压本包，打开终端进入目录。只用模型和摄像头时，网关无第三方 Python 依赖。

Windows PowerShell：

```powershell
Copy-Item config.example.env local.env
python -c "import secrets; print(secrets.token_urlsafe(32))"
notepad local.env
```

macOS / Linux：

```sh
cp config.example.env local.env
python3 -c 'import secrets; print(secrets.token_urlsafe(32))'
```

用刚生成的随机字符串替换 `BRIDGE_TOKEN`。不要沿用示例值。编辑 `local.env`，一行一个 `KEY=VALUE`，不执行 shell、不支持变量插值。同名环境变量优先于文件。实际密钥、令牌和证书私钥只留在本机，不上传、不提交代码、不发进聊天。

## 2. 配置模型

在 `local.env` 中设置：

```ini
MODEL_BASE_URL=https://api.openai.com/v1
MODEL_NAME=填写你账户实际可用的模型名
MODEL_API_KEY=填写你自己的密钥
MODEL_FORMAT=json_schema
MODEL_VISION=0
ROBOT_DRIVER=none
ROBOT_MOTION_ENABLED=0
```

上面的服务地址仅为兼容协议示例。其他服务填写它的 API 基地址，**不要带 `/chat/completions`**，网关会追加。需供应商支持标准 `messages`、`response_format` 和 `choices[0].message.content`；并非所有“兼容”服务都实现这些字段。只支持 JSON object 的服务可设 `MODEL_FORMAT=json_object`，返回值仍经过同样校验。支持图像的模型才设置 `MODEL_VISION=1`。本地服务允许 `http://127.0.0.1:端口/v1`，其他地址必须 HTTPS；本地无鉴权服务可留空 Key。没有预设模型名，避免替你选择费用或不存在的模型。

模型输出至多六步：搬运、分拣、堆叠、推物、按按钮、开抽屉。无法表达的任务应返回澄清，不能用任意代码或角度命令代替。自然语言理解依赖所配置模型的能力；结构校验不保证语义正确，所以网页先展示计划，点击确认后只在仿真执行。

## 3. HTTPS 与启动

网页在 HTTPS 上运行，本地网关也建议使用浏览器信任的 HTTPS。可使用你已有的本地证书，或按照 [mkcert 官方安装说明](https://github.com/FiloSottile/mkcert#installation) 安装 mkcert，在**运行浏览器的操作系统**上创建并信任本地 CA：

```sh
mkcert -install
mkcert -cert-file localhost.pem -key-file localhost-key.pem localhost 127.0.0.1
python server.py --env-file local.env --cert localhost.pem --key localhost-key.pem
```

macOS / Linux 如没有 `python` 命令，用 `python3`。`mkcert -install` 会修改本机证书信任库；仅在你管理的电脑上进行。保护 CA 私钥，不要分发。无需禁用浏览器证书校验。

默认仅绑定 `127.0.0.1:8765`。在 ARM LAB 的「模型、真实视觉与设备连接」中填写 `https://localhost:8765` 及本机 `BRIDGE_TOKEN`，点击连接。浏览器若询问本地网络权限，按你实际连接需求授权。`BRIDGE_ORIGIN` 默认已经对应公开站点；只允许一个精确来源，不能加尾部 `/` 或 `*`。

仅做命令行协议测试时可不加证书，使用 `http://127.0.0.1:8765`。HTTPS 网页访问 HTTP loopback 是否允许，取决于浏览器及其本地网络策略；浏览器阻止时应配置可信 HTTPS，不能关闭安全策略。手机上的 localhost 指手机本身，不是机械臂电脑；跨设备连接需要匹配主机名的受信任证书、明确的监听地址和网络配置。

## 4. 真实摄像头和标定

在独立 HTTPS 网页中点击「开启摄像头」，选择相机。默认画面在浏览器本地处理，不自动传到模型服务。开启「将当前相机帧发给模型」并点击生成时，才把一张当前帧经本地网关发送给你配置的供应商；供应商的数据政策由你所用账户决定。

把已知尺寸的矩形平面放到镜头中，输入实际宽度和深度（mm），依次点左上、右上、右下、左下，应用标定。输出以左上角为原点，X 向右、Y 向下。定位来自真实像素的红/蓝/黄连通区域；同色多物体会标记歧义，反光、阴影、遮挡和镜头畸变可能造成误差。未做镜头畸变校正，也不提供 Z 深度。移动相机、换设备或改变工作平面后重新标定。关闭相机或离开页面会释放视频轨道。

## 5. myCobot 280 实体联调

仅对本适配器对应的 myCobot 280 使用以下步骤；其他厂商、型号和控制协议需要另写驱动。先核对设备官方手册、固件、串口权限与电源状态：网关不会自动上电，不会自动回零。

```sh
python -m pip install -r requirements-hardware.txt
```

编辑 `local.env`：

```ini
ROBOT_DRIVER=mycobot280
ROBOT_PORT=填写设备实际串口
ROBOT_BAUD=115200
ROBOT_LIMITS_JSON=填写六组实际关节上下限的JSON数组
ROBOT_MOTION_ENABLED=0
```

Windows 端口形式如 `COM3`，Linux 如 `/dev/ttyUSB0`，这里只说明格式；必须用你实际端口。波特率也应依据设备配置调整。限位格式为 `[[J1最小,J1最大],...,[J6最小,J6最大]]`，单位度。**本包不预填通用限位**；请使用型号允许范围内、并结合现场可用空间进一步收紧的限位。没有六组有效限位时网关拒绝启用驱动。

先保持只读，重启网关并在网页确认六个关节读数与设备一致。完成现场确认后，改 `ROBOT_MOTION_ENABLED=1`，重启、重新连接，点击「启用本次运动控制」，然后用 `±1°` 按钮逐轴联调。运动不会因为连接成功自动开始。

- 网页每次微动 1°，速度参数为 SDK 的 5；**不是 5°/秒**。后端每次最大允许 5° 变化，SDK 速度仅允许 1–10，所有目标同时受显式关节限位约束。
- 授权使用短期会话；网页每约 700 ms 心跳，网关超过 2.5 s 未收心跳便撤销授权并请求停止。后台线程约 100 ms 检查，实际响应还受驱动 I/O 和系统调度影响。
- 一次只允许一个运动；每条命令唯一编号，重复提交被拒绝。发送成功不算到位：设备反馈角度误差须小于 1° 且不在运动；12 s 未满足则停止，不盲目重试。
- 页面隐藏、断开或主动停止会请求设备停止；反馈丢失会撤销授权。网关/操作系统失效时依然需要设备控制器自己的安全机制和实体急停。
- 页面“暂停仿真”只暂停仿真；实体设备使用独立的红色停止按钮。设备未确认停止时明确显示错误，不能当作已停止。

`ROBOT_DRIVER=mock` 仅供协议测试，界面始终显示“测试驱动，非实体机械臂”；不要拿 mock 结果当作实机验收。

## 协议与扩展驱动

每个请求（包括 `/health`）带 `Authorization: Bearer <BRIDGE_TOKEN>`，POST 使用 JSON。错误响应提供 `error`，不回显模型 Key 或供应商的响应原文。

| 方法 / 路径 | 输入与输出 |
| --- | --- |
| GET `/health` | 返回 `protocol: arm-lab/1`、模型配置、设备连接/角度/限位/运动/故障/到位结果 |
| POST `/plan` | `instruction`, `context`, 可选 JPEG/PNG `image` data URL；返回 `steps`, `explanation`, `clarification` |
| POST `/robot/arm` | `{}`；只读模式拒绝，正常返回 `lease` |
| POST `/robot/heartbeat` | `lease`；更新存活时间 |
| POST `/robot/move` | `id`, `lease`, 六角度 `angles`, `speed`；接受后需继续查询实际反馈 |
| POST `/robot/stop` | `{}`；立即撤销授权并请求设备停止，响应失败则停机未确认 |

驱动实现 `name`、`read() -> (六个角度的 list, bool运动状态)`、`move(angles, speed)`、`stop()`，再在 `main()` 明确注册。SDK 调用必须有有界超时，读取错误或停止未获确认必须抛异常。当前网页协议限定六轴；其他轴数需同时修改前后端协议和验证。不要将已有仿真关节直接映射给新驱动。

## 验证与排错

```sh
python -m unittest discover -s . -p "test_*.py" -v
```

测试使用本地 HTTP 假模型和 mock 设备，不调用付费服务，也不驱动实体设备。覆盖鉴权、精确来源、输出约束、输入图像、重复命令、限位、反馈丢失、心跳失效、到位超时与停止失败。

| 现象 | 检查 |
| --- | --- |
| 网关无法连接 | 进程/端口、令牌、受信任证书、浏览器本地网络权限、BRIDGE_ORIGIN 精确匹配 |
| 模型 HTTP 401/404/400 | 服务基地址、账户 Key、实际模型名、结构化输出支持；按供应商文档选择输出格式 |
| 无摄像头权限或设备 | 用独立 HTTPS 网页打开，检查浏览器与系统权限、USB 占用；云端浏览器无法代表你电脑上的相机 |
| 有串口但无设备反馈 | 型号/驱动、固件、电源、端口占用、波特率；检查是否真的六轴 myCobot 280 |
| 运动按钮不可点 | 是否只读、六角度反馈、是否启用本次控制、是否正在仿真任务、是否已有未完成动作 |
| 停止未确认 | 使用设备实体停止设施，排查通信，恢复前重新核对设备状态 |

## 官方接口参考

- [myCobot 280 Python API](https://docs.elephantrobotics.com/docs/mycobot_280_m5_en/3-FunctionsAndApplications/6.developmentGuide/python/2_API.html)
- [MDN getUserMedia](https://developer.mozilla.org/en-US/docs/Web/API/MediaDevices/getUserMedia)
- [OpenAI Chat Completions](https://developers.openai.com/api/reference/resources/chat/subresources/completions/methods/create)
- [Structured Outputs](https://developers.openai.com/api/docs/guides/structured-outputs)
- [图像输入](https://developers.openai.com/api/docs/guides/images-vision)
- [mkcert](https://github.com/FiloSottile/mkcert)

## v8：无需实体设备的组装模型评测

打开网页导航「组装评测」。默认可手动操作和运行规则基线；测试自己的大模型时，重新下载本包并重启网关，保持 `ROBOT_DRIVER=none` 和 `ROBOT_MOTION_ENABLED=0` 即可。无需机械臂，也无需真实摄像头。

模型配置与前文一致。网页的「大模型」页签填写网关地址和令牌。点击「只生成下一步，先审核」可检查动作再执行；「启动模型闭环」会在预算内逐步请求模型，每次都发送新的状态与上一操作结果。每步一次实际服务调用，费用由你配置的服务决定。默认总轮数预算 40 步，环境最多 80 动作；暂停会丢弃未返回决策，不能撤销已向供应商发出的请求。

`POST /assembly/step` 接收 `instruction`、`context.observation` 及可选 `image`，返回：

```json
{
  "action": {"type":"inspect","target":"assembly","dx":0,"dz":0,"yaw":0,"amount":0,"limit":0},
  "reason": "先读取当前装配状态"
}
```

装配接口只返回虚拟动作，完全不调用硬件驱动。`GET /health` 的 `capabilities` 包含 `assembly/1`；旧版网关没有此能力时网页会要求更新。

可用动作：inspect、tool、pick、align、insert、turn、retract、release、verify、halt。完整动作规范作为系统提示发给模型，字段经过网页和网关两侧校验。支持结构化输出的服务收到独立 `assembly_step` schema。

开启「发送虚拟场景图像」会把三维场景截图和结构化状态一起发送给模型，需 `MODEL_VISION=1` 及模型支持图像输入。没有开启时测试的是结构化状态决策。两者均不等于纯视觉感知测试。未连接时不会拿规则基线冒充大模型。

页面可导出每步观测、动作、反馈及最终验收 JSON，含真实控制来源和人工干预。基线成功不代表你的模型也会成功。本包的模型接口测试使用本地 HTTP 假服务；没有验证任何实际供应商模型的组装能力。
